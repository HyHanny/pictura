"use client";

import { useEffect, useRef, useState } from "react";
import { speak } from "@/lib/speech";
import type { LanguageCode } from "@/lib/languages";
import { LANGUAGE_BY_CODE } from "@/lib/languages";

type Props = {
  open: boolean;
  onClose: () => void;
  language: LanguageCode;
  emoji: string;
  indonesian: string;
  english: string;
  pronunciation: string;
  thai: string | null;
  thaiReading: string | null;
  thaiExample: string | null;
  thaiExampleReading: string | null;
  chinese: string | null;
  chineseReading: string | null;
  chineseExample: string | null;
  chineseExampleReading: string | null;
  gradient: string;
  onCompletePractice?: () => void;
};

const BRUSH_COLORS = [
  { name: "Hitam Tinta", color: "#1e293b" },
  { name: "Pink Cerah", color: "#ec4899" },
  { name: "Biru Elektrik", color: "#2563eb" },
  { name: "Ungu Neon", color: "#7c3aed" },
  { name: "Hijau Zamrud", color: "#059669" },
  { name: "Oranye Api", color: "#ea580c" },
];

function getReadingTips(lang: LanguageCode, script: string, reading: string | null): {
  title: string;
  steps: string[];
  writingTip: string;
} {
  if (lang === "zh") {
    return {
      title: "Panduan Membaca Pinyin & Nada Mandarin 🇨🇳",
      steps: [
        `Karakter Hanzi: "${script}" dibaca "${reading ?? "-"}".`,
        "Nada 1 (ā) datar tinggi • Nada 2 (á) naik seperti bertanya • Nada 3 (ǎ) turun lalu naik • Nada 4 (à) tegas menurun.",
        "Dengarkan tombol 🐢 Lambat untuk menirukan intonasi nada dengan tepat.",
      ],
      writingTip:
        "Urutan Goresan Hanzi: Tulis dari atas ke bawah, kiri ke kanan, garis mendatar dulu baru garis tegak, dan bagian luar sebelum bagian dalam.",
    };
  }
  if (lang === "th") {
    return {
      title: "Panduan Membaca Aksara Thailand 🇹🇭",
      steps: [
        `Aksara Thai: "${script}" dibaca "${reading ?? "-"}".`,
        "Aksara Thailand ditulis tanpa spasi antar kata; vokal bisa berada di depan (เช่น แ-, เ-), di atas, di bawah, atau di belakang konsonan.",
        "Mulai goresan dari lingkaran kecil (kepala huruf) jika huruf memiliki lengkungan bulat.",
      ],
      writingTip:
        "Cara Menulis Aksara Thai: Selalu mulai dari bulatan kecil ('kepala' huruf) lalu tarik garis mengikuti lekukan tanpa mengangkat pena.",
    };
  }
  if (lang === "id") {
    return {
      title: "Panduan Membaca Bahasa Indonesia 🇮🇩",
      steps: [
        `Kata: "${script}" — dibaca sesuai ejaan fonetis suku kata.`,
        "Setiap huruf dilafalkan jelas dan konsisten.",
      ],
      writingTip: "Latih tulisan tangan rapi mengikuti garis bantu di kanvas.",
    };
  }
  return {
    title: "Panduan Membaca & Pelafalan Inggris 🇬🇧",
    steps: [
      `Kata: "${script}" • Simbol fonetik IPA: ${reading ?? "-"}.`,
      "Perhatikan tekanan suku kata (tanda ˈ pada IPA menunjukkan suku kata yang ditekan).",
    ],
    writingTip:
      "Latih penulisan ejaan huruf (spelling) di atas kanvas agar memori otot dan visual bekerja bersamaan.",
  };
}

export default function WritingPracticeModal({
  open,
  onClose,
  language,
  emoji,
  indonesian,
  english,
  pronunciation,
  thai,
  thaiReading,
  thaiExample,
  thaiExampleReading,
  chinese,
  chineseReading,
  chineseExample,
  chineseExampleReading,
  gradient,
  onCompletePractice,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushColor, setBrushColor] = useState(BRUSH_COLORS[1].color);
  const [brushSize, setBrushSize] = useState(10);
  const [showShadowGuide, setShowShadowGuide] = useState(true);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [practicedDone, setPracticedDone] = useState(false);

  const langDef = LANGUAGE_BY_CODE[language];

  const scriptText =
    language === "th"
      ? thai || english
      : language === "zh"
        ? chinese || english
        : language === "id"
          ? indonesian
          : english;

  const readingText =
    language === "th"
      ? thaiReading
      : language === "zh"
        ? chineseReading
        : language === "en"
          ? pronunciation
          : null;

  const exampleText =
    language === "th"
      ? thaiExample
      : language === "zh"
        ? chineseExample
        : language === "en"
          ? english
          : indonesian;

  const exampleReadingText =
    language === "th"
      ? thaiExampleReading
      : language === "zh"
        ? chineseExampleReading
        : null;

  const characters = Array.from(scriptText);
  const tips = getReadingTips(language, scriptText, readingText);

  useEffect(() => {
    if (!open) return;
    setHasDrawn(false);
    setPracticedDone(false);
    const timer = setTimeout(() => {
      clearCanvas();
    }, 50);
    return () => clearTimeout(timer);
  }, [open, scriptText, language]);

  function clearCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  }

  function getPoint(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }

  function handlePointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    e.currentTarget.setPointerCapture(e.pointerId);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const { x, y } = getPoint(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = brushColor;
    ctx.lineWidth = brushSize;
    setIsDrawing(true);
    setHasDrawn(true);
  }

  function handlePointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const { x, y } = getPoint(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  }

  function handlePointerUp() {
    setIsDrawing(false);
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 p-3 sm:p-5 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-pop my-auto w-full max-w-2xl overflow-hidden rounded-[32px] bg-white shadow-2xl"
      >
        {/* HEADER */}
        <div className={`bg-gradient-to-r ${gradient} p-5 text-white`}>
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="text-5xl drop-shadow-md">{emoji}</span>
              <div>
                <span className="inline-block rounded-full bg-black/25 px-2.5 py-0.5 text-xs font-bold">
                  {langDef.flag} Studio Menulis & Membaca • {langDef.label}
                </span>
                <h2 className="mt-1 text-2xl font-black drop-shadow-sm">
                  {scriptText}{" "}
                  <span className="text-base font-normal opacity-90">
                    ({indonesian} / {english})
                  </span>
                </h2>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/25 text-lg font-bold text-white backdrop-blur-md hover:bg-white/40"
              aria-label="Tutup"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="max-h-[80vh] space-y-5 overflow-y-auto p-5">
          {/* BAGIAN 1: CARA MEMBACA & PELAFALAN */}
          <div className="rounded-2xl border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-orange-600">
                  📖 Cara Membaca & Pelafalan
                </p>
                <div className="mt-1 flex flex-wrap items-baseline gap-3">
                  <span className="text-3xl font-black text-slate-900">{scriptText}</span>
                  {readingText && (
                    <span className="rounded-xl bg-orange-200/70 px-3 py-1 font-mono text-lg font-bold text-orange-900">
                      {readingText}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => speak(scriptText, langDef.bcp47, { rate: 0.95 })}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-orange-400 to-pink-500 px-3.5 py-2 text-xs font-bold text-white shadow hover:scale-105"
                >
                  🔊 Normal
                </button>
                <button
                  type="button"
                  onClick={() => speak(scriptText, langDef.bcp47, { rate: 0.55 })}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-sky-400 to-indigo-500 px-3.5 py-2 text-xs font-bold text-white shadow hover:scale-105"
                >
                  🐢 Lambat & Jelas
                </button>
              </div>
            </div>

            {/* Rincian per karakter / huruf */}
            <div className="mt-3">
              <p className="text-xs font-bold text-slate-600">
                Susunan Huruf / Karakter ({characters.length} bagian):
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {characters.map((ch, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => speak(ch, langDef.bcp47, { rate: 0.7 })}
                    className="group flex flex-col items-center justify-center rounded-2xl border-2 border-orange-200 bg-white px-3.5 py-2 shadow-sm transition hover:-translate-y-0.5 hover:border-pink-400"
                    title="Klik untuk dengar bunyi karakter"
                  >
                    <span className="text-[10px] font-bold text-slate-400">#{idx + 1}</span>
                    <span className="text-2xl font-black text-slate-800 group-hover:text-pink-600">
                      {ch}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Tips membaca */}
            <div className="mt-3 space-y-1 rounded-xl bg-white/80 p-3 text-xs text-slate-700">
              <p className="font-bold text-slate-900">{tips.title}</p>
              <ul className="list-disc space-y-1 pl-4">
                {tips.steps.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
              {exampleText && (
                <div className="mt-2 border-t border-orange-100 pt-2">
                  <span className="font-bold text-orange-700">Contoh Kalimat: </span>
                  <span className="font-semibold">{exampleText}</span>
                  {exampleReadingText && (
                    <span className="ml-1 font-mono text-slate-600">({exampleReadingText})</span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* BAGIAN 2: KANVAS LATIHAN MENULIS */}
          <div className="rounded-2xl border-2 border-pink-200 bg-gradient-to-br from-pink-50 via-white to-sky-50 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-pink-600">
                  ✍️ Kanvas Latihan Menulis Aksara
                </p>
                <p className="text-xs text-slate-600">{tips.writingTip}</p>
              </div>
              <label className="flex cursor-pointer items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-700 shadow-sm">
                <input
                  type="checkbox"
                  checked={showShadowGuide}
                  onChange={(e) => setShowShadowGuide(e.target.checked)}
                  className="accent-pink-500"
                />
                Bayangan Huruf
              </label>
            </div>

            {/* Pilihan warna kuas */}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">Warna Tinta:</span>
                {BRUSH_COLORS.map((b) => (
                  <button
                    key={b.color}
                    type="button"
                    onClick={() => setBrushColor(b.color)}
                    style={{ backgroundColor: b.color }}
                    className={`h-7 w-7 rounded-full transition ${
                      brushColor === b.color ? "scale-110 ring-4 ring-pink-300" : "opacity-80 hover:opacity-100"
                    }`}
                    title={b.name}
                    aria-label={b.name}
                  />
                ))}
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">Tebal:</span>
                {[6, 10, 16].map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setBrushSize(sz)}
                    className={`rounded-lg px-2.5 py-1 text-xs font-bold ${
                      brushSize === sz
                        ? "bg-slate-900 text-white"
                        : "bg-white text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    {sz === 6 ? "Tipis" : sz === 10 ? "Sedang" : "Tebal"}
                  </button>
                ))}
              </div>
            </div>

            {/* Area Kanvas dengan garis bantu Tianzige / kotak latihan */}
            <div className="relative mt-3 h-64 w-full overflow-hidden rounded-2xl border-2 border-dashed border-pink-300 bg-white shadow-inner">
              {/* Garis bantu kotak latihan */}
              <svg
                className="pointer-events-none absolute inset-0 h-full w-full opacity-30"
                viewBox="0 0 400 200"
                preserveAspectRatio="none"
              >
                <line x1="0" y1="100" x2="400" y2="100" stroke="#f43f5e" strokeWidth="1" strokeDasharray="6,6" />
                <line x1="200" y1="0" x2="200" y2="200" stroke="#f43f5e" strokeWidth="1" strokeDasharray="6,6" />
                <line x1="0" y1="0" x2="400" y2="200" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="4,6" />
                <line x1="400" y1="0" x2="0" y2="200" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="4,6" />
              </svg>

              {/* Panduan bayangan karakter */}
              {showShadowGuide && (
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center select-none">
                  <span
                    className={`font-black tracking-widest text-slate-200 ${
                      scriptText.length <= 2
                        ? "text-[135px]"
                        : scriptText.length <= 5
                          ? "text-[85px]"
                          : "text-[56px]"
                    }`}
                  >
                    {scriptText}
                  </span>
                </div>
              )}

              <canvas
                ref={canvasRef}
                width={640}
                height={300}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={handlePointerUp}
                className="relative z-10 h-full w-full cursor-crosshair touch-none"
              />
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={clearCanvas}
                className="rounded-xl bg-slate-200 px-4 py-2.5 text-xs font-bold text-slate-700 transition hover:bg-slate-300"
              >
                🧹 Bersihkan Kanvas
              </button>

              <div className="flex items-center gap-2">
                {practicedDone && (
                  <span className="text-xs font-bold text-emerald-600">
                    🎉 Mantap! +10 XP Latihan Menulis!
                  </span>
                )}
                <button
                  type="button"
                  disabled={!hasDrawn || practicedDone}
                  onClick={() => {
                    setPracticedDone(true);
                    onCompletePractice?.();
                  }}
                  className="rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-5 py-2.5 text-xs font-bold text-white shadow-md transition hover:scale-105 disabled:opacity-50"
                >
                  {practicedDone ? "✓ Sudah Dinilai" : "✨ Selesai Latihan (+10 XP)"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
