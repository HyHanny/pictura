"use client";

import { useEffect, useMemo, useState } from "react";
import PaletteBackground from "./PaletteBackground";
import CategoryTile from "./CategoryTile";
import LearnView, { type DbCard, type Mode } from "./LearnView";
import XpHeader from "./XpHeader";
import BadgeModal from "./BadgeModal";
import LanguageSwitcher from "./LanguageSwitcher";
import SettingsModal from "./SettingsModal";
import { LearnProvider, useLearn } from "@/lib/LearnContext";
import { LANGUAGES, LANGUAGE_BY_CODE } from "@/lib/languages";
import type { CardCategory } from "@/lib/cards";

type CategoryInfo = {
  key: CardCategory;
  info: {
    label: string;
    emoji: string;
    gradient: string;
    tagline: string;
  };
  count: number;
};

type Props = {
  cards: DbCard[];
  categories: CategoryInfo[];
  initialFavoriteIds: number[];
  initialStats: Record<number, { remembered: number; forgotten: number }>;
};

function HomeClientInner({
  cards: initialCards,
  categories,
  initialFavoriteIds,
  initialStats,
}: Props) {
  const { language, setLanguage } = useLearn();
  const currentLang = LANGUAGE_BY_CODE[language];

  const [cards, setCards] = useState<DbCard[]>(initialCards);
  const [view, setView] = useState<"home" | "learn">("home");
  const [selectedCategory, setSelectedCategory] = useState<CardCategory | null>(null);
  const [mode, setMode] = useState<Mode>("flashcard");
  const [badgeModalOpen, setBadgeModalOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [favoriteIds, setFavoriteIds] = useState<Set<number>>(new Set(initialFavoriteIds));
  const [stats, setStats] = useState<Record<number, { remembered: number; forgotten: number }>>(
    initialStats,
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { getSessionId } = await import("@/lib/session");
        const sid = getSessionId();
        const [favRes, progRes] = await Promise.all([
          fetch(`/api/favorites?sessionId=${sid}`),
          fetch(`/api/progress?sessionId=${sid}`),
        ]);
        const favData = await favRes.json();
        const progData = await progRes.json();
        if (cancelled) return;
        if (favData.ok) setFavoriteIds(new Set(favData.favorites ?? []));
        if (progData.ok && Array.isArray(progData.stats)) {
          const next: Record<number, { remembered: number; forgotten: number }> = {};
          for (const s of progData.stats) {
            next[s.cardId] = {
              remembered: Number(s.rememberedCount ?? 0),
              forgotten: Number(s.forgottenCount ?? 0),
            };
          }
          setStats(next);
        }
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  function startLearn(cat: CardCategory | null, m: Mode = "flashcard") {
    setSelectedCategory(cat);
    setMode(m);
    setView("learn");
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const allCategoryKeys = useMemo(() => categories.map((c) => c.key), [categories]);

  const categoriesWithDynamicCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const c of cards) {
      counts.set(c.category, (counts.get(c.category) ?? 0) + 1);
    }
    return categories.map((cat) => ({
      ...cat,
      count: counts.get(cat.key) ?? cat.count,
    }));
  }, [cards, categories]);

  return (
    <>
      <PaletteBackground />

      <main className="mx-auto max-w-5xl px-4 pb-24 pt-8 sm:px-6 sm:pt-12">
        {/* TOP BAR: XP/Badges left, LanguageSwitcher & Settings right */}
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-stretch">
          <div className="flex-1">
            <XpHeader onOpenBadges={() => setBadgeModalOpen(true)} />
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2">
            <LanguageSwitcher />
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              className="flex items-center gap-1.5 rounded-full bg-slate-900 px-4 py-2 text-xs sm:text-sm font-extrabold text-white shadow-lg transition hover:scale-105"
            >
              ⚙️ Pengaturan
            </button>
          </div>
        </div>

        {/* HEADER */}
        <header className="mb-8 flex flex-col items-center text-center">
          <div className="relative">
            <div className="rainbow-border absolute -inset-1 rounded-full blur-md opacity-70" />
            <div className="relative grid h-24 w-24 place-items-center rounded-full bg-white shadow-2xl">
              <span className="text-5xl">🦄</span>
            </div>
          </div>
          <h1 className="mt-5 bg-gradient-to-r from-pink-500 via-orange-500 to-amber-500 bg-clip-text text-5xl font-black tracking-tight text-transparent sm:text-6xl">
            Pictura
          </h1>
          <p className="mt-2 max-w-xl text-lg font-semibold text-slate-700">
            Belajar bahasa{" "}
            <span className="underline decoration-pink-400 decoration-4 underline-offset-4">
              {currentLang.label}
            </span>{" "}
            dengan gambar, warna ceria, cara baca & latihan menulis ✨
          </p>

          {/* TOMBOL PILIH BAHASA LANGSUNG */}
          <div className="mt-5 w-full max-w-2xl rounded-3xl bg-white/85 p-4 shadow-xl backdrop-blur-md">
            <div className="flex items-center justify-between">
              <p className="text-xs font-extrabold uppercase tracking-wider text-slate-600">
                🌍 Pilih Bahasa yang Ingin Kamu Pelajari:
              </p>
              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                className="text-xs font-bold text-pink-600 hover:underline"
              >
                ⚙️ Atur Suara & Tema Warna
              </button>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {LANGUAGES.map((l) => {
                const active = l.code === language;
                return (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => setLanguage(l.code)}
                    className={`flex flex-col items-center justify-center rounded-2xl p-3 text-center font-bold transition ${
                      active
                        ? `bg-gradient-to-br ${l.gradient} text-white shadow-lg scale-105 ring-4 ring-amber-300`
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    <span className="text-3xl">{l.flag}</span>
                    <span className="mt-1 text-xs font-extrabold">{l.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </header>

        {view === "home" ? (
          <>
            {/* QUICK ACTIONS (6 FITUR UTAMA) */}
            <section className="mb-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <button
                type="button"
                onClick={() => startLearn(null, "flashcard")}
                className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-pink-400 via-rose-500 to-fuchsia-600 p-6 text-left text-white shadow-2xl transition hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-white/10" />
                <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/30 blur-2xl transition group-hover:scale-125" />
                <div className="relative z-10">
                  <span className="text-5xl drop-shadow-lg">🎴</span>
                  <h3 className="mt-3 text-2xl font-bold drop-shadow-md">Kartu Putar 3D</h3>
                  <p className="mt-1 text-sm font-medium opacity-90">
                    Hafal kata {currentLang.flag} dengan gambar besar & contoh kalimat
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => startLearn(null, "writing")}
                className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-violet-500 via-purple-500 to-indigo-600 p-6 text-left text-white shadow-2xl transition hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-white/10" />
                <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/30 blur-2xl transition group-hover:scale-125" />
                <div className="relative z-10">
                  <span className="text-5xl drop-shadow-lg">✍️</span>
                  <h3 className="mt-3 text-2xl font-bold drop-shadow-md">Studio Tulis & Baca</h3>
                  <p className="mt-1 text-sm font-medium opacity-90">
                    Kanvas latihan menulis aksara Thai/Hanzi & cara bacanya
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => startLearn(null, "scriptguide")}
                className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-emerald-400 via-teal-500 to-cyan-600 p-6 text-left text-white shadow-2xl transition hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-white/10" />
                <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/30 blur-2xl transition group-hover:scale-125" />
                <div className="relative z-10">
                  <span className="text-5xl drop-shadow-lg">📖</span>
                  <h3 className="mt-3 text-2xl font-bold drop-shadow-md">Aksara & Nada Dasar</h3>
                  <p className="mt-1 text-sm font-medium opacity-90">
                    Huruf Thai bergambar (ก ไก่), 4 Nada Mandarin & Piktograf Hanzi
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => startLearn(null, "match")}
                className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-orange-400 via-amber-500 to-yellow-500 p-6 text-left text-white shadow-2xl transition hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-white/10" />
                <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/30 blur-2xl transition group-hover:scale-125" />
                <div className="relative z-10">
                  <span className="text-5xl drop-shadow-lg">🧩</span>
                  <h3 className="mt-3 text-2xl font-bold drop-shadow-md">Game Cocok Gambar</h3>
                  <p className="mt-1 text-sm font-medium opacity-90">
                    Pasangkan gambar emoji dengan aksara & bunyi suaranya
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => startLearn(null, "quiz")}
                className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-rose-400 via-pink-500 to-red-500 p-6 text-left text-white shadow-2xl transition hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-white/10" />
                <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/30 blur-2xl transition group-hover:scale-125" />
                <div className="relative z-10">
                  <span className="text-5xl drop-shadow-lg">🎯</span>
                  <h3 className="mt-3 text-2xl font-bold drop-shadow-md">Kuis Seru</h3>
                  <p className="mt-1 text-sm font-medium opacity-90">
                    Tebak aksara & arti dari gambar untuk panen XP
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => startLearn(null, "favorites")}
                className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-600 p-6 text-left text-white shadow-2xl transition hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-white/10" />
                <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/30 blur-2xl transition group-hover:scale-125" />
                <div className="relative z-10">
                  <span className="text-5xl drop-shadow-lg">⭐</span>
                  <h3 className="mt-3 text-2xl font-bold drop-shadow-md">Kata Favorit</h3>
                  <p className="mt-1 text-sm font-medium opacity-90">
                    Ulangi kata-kata yang ditandai dengan Spaced Repetition
                  </p>
                </div>
              </button>
            </section>

            {/* CATEGORIES */}
            <section className="mb-12">
              <div className="mb-5 flex items-end justify-between">
                <h2 className="text-3xl font-black text-slate-900">
                  Pilih <span className="text-pink-500">Kategori Gambar</span> 🎨
                </h2>
                <span className="text-sm font-medium text-slate-500">
                  {cards.length} kata tersedia ({currentLang.flag} {currentLang.shortLabel})
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                {categoriesWithDynamicCounts.map((c, i) => (
                  <CategoryTile
                    key={c.key}
                    label={c.info.label}
                    emoji={c.info.emoji}
                    gradient={c.info.gradient}
                    tagline={c.info.tagline}
                    count={c.count}
                    onClick={() => startLearn(c.key, "flashcard")}
                    delay={i * 80}
                  />
                ))}
              </div>
            </section>

            {/* TIPS / VISUAL MEMORY */}
            <section className="mb-12 rounded-[32px] bg-white/75 p-6 backdrop-blur-md shadow-xl sm:p-8">
              <h2 className="text-2xl font-black text-slate-900">
                🧠 Kenapa Belajar di Pictura Tidak Bikin Mengantuk?
              </h2>
              <p className="mt-1 font-medium text-slate-600">
                Menggabungkan memori visual, warna dopamin, suara, dan gerakan tangan menulis:
              </p>
              <div className="mt-5 grid gap-4 sm:grid-cols-3">
                {[
                  {
                    emoji: "🌈",
                    title: "Warna Dopamin Anti-Ngantuk",
                    desc: "Setiap kategori punya gradien cerah & tema latar yang bisa diganti kapan saja di Pengaturan.",
                    gradient: "from-rose-200 to-pink-300",
                  },
                  {
                    emoji: "✍️",
                    title: "Kanvas Menulis & Piktograf",
                    desc: "Huruf Thailand (ก ไก่) dan Hanzi China (口, 木, 山) dipelajari lewat bentuk gambarnya lalu ditulis langsung.",
                    gradient: "from-amber-200 to-orange-300",
                  },
                  {
                    emoji: "🔊",
                    title: "Suara Pelafalan & Nada",
                    desc: "Lengkap dengan Pinyin bernada, romanisasi Thai, IPA, serta mode suara lambat (0.6x) untuk pemula.",
                    gradient: "from-sky-200 to-blue-300",
                  },
                ].map((t) => (
                  <div
                    key={t.title}
                    className={`rounded-2xl bg-gradient-to-br ${t.gradient} p-5 text-slate-800 shadow-md`}
                  >
                    <span className="text-4xl">{t.emoji}</span>
                    <h4 className="mt-3 text-lg font-bold">{t.title}</h4>
                    <p className="mt-1 text-sm font-medium">{t.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* FOOTER */}
            <footer className="text-center text-sm font-medium text-slate-500">
              dibuat dengan 💖 untuk belajar multi-bahasa yang lebih seru & mudah dihafal
            </footer>
          </>
        ) : (
          <section>
            <button
              type="button"
              onClick={() => setView("home")}
              className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-2 text-sm font-bold text-slate-700 shadow hover:bg-white"
            >
              ← Kembali ke Beranda
            </button>
            <LearnView
              key={`${selectedCategory ?? "all"}-${mode}`}
              cards={cards}
              allCategories={allCategoryKeys}
              initialFavorites={favoriteIds}
              initialStats={new Map(Object.entries(stats).map(([k, v]) => [Number(k), v]))}
              initialCategory={selectedCategory}
              initialMode={mode}
            />
          </section>
        )}
      </main>

      <BadgeModal open={badgeModalOpen} onClose={() => setBadgeModalOpen(false)} />
      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </>
  );
}

export default function HomeClient(props: Props) {
  return (
    <LearnProvider>
      <HomeClientInner {...props} />
    </LearnProvider>
  );
}
