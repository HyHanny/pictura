"use client";

import { useState } from "react";
import { speak, stopSpeaking } from "@/lib/speech";

type Props = {
  text: string;
  lang?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
  label?: string;
};

const SIZE_MAP: Record<NonNullable<Props["size"]>, string> = {
  sm: "h-8 w-8 text-base",
  md: "h-10 w-10 text-lg",
  lg: "h-14 w-14 text-2xl",
};

export default function SpeakerButton({
  text,
  lang = "en-US",
  size = "md",
  className = "",
  label,
}: Props) {
  const [active, setActive] = useState(false);

  function handle() {
    if (active) {
      stopSpeaking();
      setActive(false);
      return;
    }
    setActive(true);
    speak(text, lang);
    // Visual reset (browser speechend is inconsistent across engines)
    setTimeout(() => setActive(false), 1800);
  }

  const langLabel = (lang || "en-US").toUpperCase().slice(0, 2);

  return (
    <button
      type="button"
      onClick={handle}
      aria-label={`Dengarkan ${label ?? text}`}
      title={`Dengarkan pelafalan ${langLabel}`}
      className={`relative grid place-items-center rounded-full bg-white/30 text-white shadow-md backdrop-blur-md transition hover:scale-110 active:scale-95 ${
        SIZE_MAP[size]
      } ${active ? "ring-4 ring-white/60" : ""} ${className}`}
    >
      <span className="text-xl">{active ? "🔊" : "🔉"}</span>
      <span className="pointer-events-none absolute -bottom-2 rounded-full bg-slate-900 px-1.5 py-0.5 text-[9px] font-bold leading-none text-white shadow">
        {langLabel}
      </span>
    </button>
  );
}
