"use client";

import { useEffect, useState } from "react";
import type { DbCard } from "./LearnView";
import { useLearn } from "@/lib/LearnContext";
import { LANGUAGE_BY_CODE } from "@/lib/languages";
import { speak } from "@/lib/speech";

type Tile = {
  tileId: string;
  cardId: number;
  kind: "picture" | "script";
  displayMain: string;
  displaySub: string;
  gradient: string;
  speakText: string;
};

function shuffle<T>(arr: T[]): T[] {
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

export default function MemoryMatchGame({
  cards,
  onWinRound,
}: {
  cards: DbCard[];
  onWinRound?: () => void;
}) {
  const { language, speechRate } = useLearn();
  const langDef = LANGUAGE_BY_CODE[language];

  const [tiles, setTiles] = useState<Tile[]>([]);
  const [selectedTileIds, setSelectedTileIds] = useState<string[]>([]);
  const [matchedCardIds, setMatchedCardIds] = useState<Set<number>>(new Set());
  const [wrongPair, setWrongPair] = useState<string[]>([]);
  const [moves, setMoves] = useState(0);

  function getTarget(c: DbCard): { script: string; reading: string } {
    if (language === "th") {
      return { script: c.thai ?? c.english, reading: c.thaiReading ?? "" };
    }
    if (language === "zh") {
      return { script: c.chinese ?? c.english, reading: c.chineseReading ?? "" };
    }
    if (language === "id") {
      return { script: c.indonesian, reading: c.english };
    }
    return { script: c.english, reading: c.pronunciation };
  }

  function startNewGame() {
    const picked = shuffle(cards).slice(0, 6);
    const pairTiles: Tile[] = [];
    for (const c of picked) {
      const t = getTarget(c);
      pairTiles.push({
        tileId: `pic-${c.id}`,
        cardId: c.id,
        kind: "picture",
        displayMain: c.emoji,
        displaySub: c.indonesian,
        gradient: c.gradient,
        speakText: t.script,
      });
      pairTiles.push({
        tileId: `scr-${c.id}`,
        cardId: c.id,
        kind: "script",
        displayMain: t.script,
        displaySub: t.reading,
        gradient: c.gradient,
        speakText: t.script,
      });
    }
    setTiles(shuffle(pairTiles));
    setSelectedTileIds([]);
    setMatchedCardIds(new Set());
    setWrongPair([]);
    setMoves(0);
  }

  useEffect(() => {
    startNewGame();
  }, [cards, language]);

  function handleSelectTile(tile: Tile) {
    if (matchedCardIds.has(tile.cardId)) return;
    if (selectedTileIds.includes(tile.tileId)) return;
    if (selectedTileIds.length >= 2) return;

    speak(tile.speakText, langDef.bcp47, { rate: speechRate });

    const nextSelected = [...selectedTileIds, tile.tileId];
    setSelectedTileIds(nextSelected);

    if (nextSelected.length === 2) {
      setMoves((m) => m + 1);
      const first = tiles.find((t) => t.tileId === nextSelected[0]);
      const second = tile;
      if (first && first.cardId === second.cardId && first.kind !== second.kind) {
        const nextMatched = new Set(matchedCardIds);
        nextMatched.add(tile.cardId);
        setMatchedCardIds(nextMatched);
        setSelectedTileIds([]);
        if (nextMatched.size === tiles.length / 2) {
          onWinRound?.();
        }
      } else {
        setWrongPair(nextSelected);
        setTimeout(() => {
          setSelectedTileIds([]);
          setWrongPair([]);
        }, 700);
      }
    }
  }

  const allMatched = tiles.length > 0 && matchedCardIds.size === tiles.length / 2;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl bg-gradient-to-r from-pink-500 via-orange-400 to-amber-400 p-5 text-white shadow-xl">
        <div>
          <h3 className="text-2xl font-black">
            🧩 Game Cocok Gambar & Aksara ({langDef.flag} {langDef.label})
          </h3>
          <p className="text-xs sm:text-sm font-medium opacity-95">
            Pasangkan kartu <strong>Gambar Emoji</strong> dengan <strong>Aksara & Cara Bacanya</strong>! Suara akan otomatis berbunyi saat diklik.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="rounded-full bg-black/25 px-4 py-1.5 text-xs font-extrabold">
            Langkah: {moves} • Cocok: {matchedCardIds.size}/{tiles.length / 2}
          </span>
          <button
            type="button"
            onClick={startNewGame}
            className="rounded-2xl bg-white px-4 py-2 text-xs font-extrabold text-slate-900 shadow hover:scale-105"
          >
            🔄 Acak Ulang
          </button>
        </div>
      </div>

      {allMatched && (
        <div className="animate-pop rounded-3xl bg-gradient-to-r from-emerald-400 to-teal-500 p-6 text-center text-white shadow-2xl">
          <p className="text-5xl">🎉🏆🎉</p>
          <h4 className="mt-2 text-2xl font-black">
            Luar Biasa! Semua Pasangan Berhasil Dicocokkan! (+25 XP)
          </h4>
          <p className="mt-1 text-sm opacity-95">
            Kamu menyelesaikan ronde ini dalam {moves} langkah.
          </p>
          <button
            type="button"
            onClick={startNewGame}
            className="mt-4 rounded-2xl bg-white px-6 py-2.5 text-sm font-extrabold text-emerald-700 shadow-lg hover:scale-105"
          >
            🚀 Main Ronde Baru
          </button>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {tiles.map((tile) => {
          const isMatched = matchedCardIds.has(tile.cardId);
          const isSelected = selectedTileIds.includes(tile.tileId);
          const isWrong = wrongPair.includes(tile.tileId);

          return (
            <button
              key={tile.tileId}
              type="button"
              disabled={isMatched}
              onClick={() => handleSelectTile(tile)}
              className={`relative flex min-h-[130px] flex-col items-center justify-center rounded-3xl p-4 text-center transition-all duration-200 ${
                isMatched
                  ? "scale-95 bg-emerald-100 text-emerald-700 opacity-60 ring-2 ring-emerald-400"
                  : isWrong
                    ? "animate-wiggle bg-rose-500 text-white ring-4 ring-rose-300"
                    : isSelected
                      ? `scale-105 bg-gradient-to-br ${tile.gradient} text-white shadow-2xl ring-4 ring-amber-300`
                      : "bg-white text-slate-800 shadow-lg hover:-translate-y-1 hover:shadow-xl"
              }`}
            >
              <span className="absolute top-2.5 left-3 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-500">
                {tile.kind === "picture" ? "🖼️ Gambar" : `${langDef.flag} Aksara`}
              </span>

              {isMatched && (
                <span className="absolute top-2.5 right-3 text-sm font-black">✓</span>
              )}

              <span
                className={`mt-3 font-black ${
                  tile.kind === "picture" ? "text-5xl" : "text-3xl"
                }`}
              >
                {tile.displayMain}
              </span>

              {tile.displaySub && (
                <span
                  className={`mt-1.5 text-xs font-bold ${
                    isSelected ? "text-white" : "text-slate-600"
                  } font-mono`}
                >
                  {tile.displaySub}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
