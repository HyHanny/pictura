"use client";

import { useEffect, useMemo, useState } from "react";
import VocabCard from "./VocabCard";
import ConfettiBurst from "./ConfettiBurst";
import Mascot from "./Mascot";
import LevelUpToast from "./LevelUpToast";
import WritingPracticeModal from "./WritingPracticeModal";
import ScriptGuideView from "./ScriptGuideView";
import MemoryMatchGame from "./MemoryMatchGame";
import { CATEGORY_INFO, type CardCategory } from "@/lib/categories";
import { useXp } from "@/lib/useXp";
import { BADGE_BY_CODE } from "@/lib/gamification";
import { useLearn } from "@/lib/LearnContext";
import { LANGUAGE_BY_CODE, LANGUAGES } from "@/lib/languages";
import { speak } from "@/lib/speech";

export type DbCard = {
  id: number;
  indonesian: string;
  english: string;
  pronunciation: string;
  category: CardCategory;
  emoji: string;
  gradient: string;
  exampleId: string | null;
  exampleEn: string | null;
  thai: string | null;
  thaiReading: string | null;
  thaiExample: string | null;
  thaiExampleReading: string | null;
  chinese: string | null;
  chineseReading: string | null;
  chineseExample: string | null;
  chineseExampleReading: string | null;
};

type Stats = Map<number, { remembered: number; forgotten: number }>;
type Favorites = Set<number>;

type Mode = "flashcard" | "writing" | "scriptguide" | "match" | "quiz" | "favorites";
export type { Mode };

type Props = {
  cards: DbCard[];
  allCategories: CardCategory[];
  initialFavorites: Favorites;
  initialStats: Stats;
  initialCategory?: CardCategory | null;
  initialMode?: Mode;
};

type QuizQuestion = {
  card: DbCard;
  options: { label: string; sub?: string | null; cardId: number }[];
};

function shuffle<T>(arr: T[]): T[] {
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

export default function LearnView({
  cards,
  allCategories,
  initialFavorites,
  initialStats,
  initialCategory = null,
  initialMode = "flashcard",
}: Props) {
  const { language, setLanguage } = useLearn();
  const langDef = LANGUAGE_BY_CODE[language];

  const [mode, setMode] = useState<Mode>(initialMode);
  const [activeCategory, setActiveCategory] = useState<CardCategory | "all">(
    initialCategory ?? "all",
  );
  const [index, setIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [favorites, setFavorites] = useState<Favorites>(initialFavorites);
  const [stats, setStats] = useState<Stats>(initialStats);
  const [confettiKey, setConfettiKey] = useState(0);
  const [practiceCard, setPracticeCard] = useState<DbCard | null>(null);

  useEffect(() => {
    setFavorites(initialFavorites);
  }, [initialFavorites]);

  useEffect(() => {
    setStats(initialStats);
  }, [initialStats]);

  // Quiz state
  const [quiz, setQuiz] = useState<QuizQuestion | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizTotal, setQuizTotal] = useState(0);
  const [quizStreak, setQuizStreak] = useState(0);
  const [quizBestStreak, setQuizBestStreak] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizFeedback, setQuizFeedback] = useState<"correct" | "wrong" | null>(null);
  const [quizLastCard, setQuizLastCard] = useState<DbCard | null>(null);

  const { award, checkCategoryMaster } = useXp();
  const [toastLevel, setToastLevel] = useState<number | null>(null);
  const [toastBadge, setToastBadge] = useState<{
    code: string;
    title: string;
    emoji: string;
    gradient: string;
  } | null>(null);

  function getTargetWord(c: DbCard): { script: string; reading: string | null } {
    if (language === "th") return { script: c.thai ?? c.english, reading: c.thaiReading };
    if (language === "zh") return { script: c.chinese ?? c.english, reading: c.chineseReading };
    if (language === "id") return { script: c.indonesian, reading: null };
    return { script: c.english, reading: c.pronunciation };
  }

  const filteredCards = useMemo(() => {
    let base = cards;
    if (mode === "favorites") {
      base = base.filter((c) => favorites.has(c.id));
    } else if (activeCategory !== "all") {
      base = base.filter((c) => c.category === activeCategory);
    }
    const q = searchQuery.trim().toLowerCase();
    if (!q) return base;
    return base.filter(
      (c) =>
        c.indonesian.toLowerCase().includes(q) ||
        c.english.toLowerCase().includes(q) ||
        (c.thai && c.thai.toLowerCase().includes(q)) ||
        (c.thaiReading && c.thaiReading.toLowerCase().includes(q)) ||
        (c.chinese && c.chinese.toLowerCase().includes(q)) ||
        (c.chineseReading && c.chineseReading.toLowerCase().includes(q)),
    );
  }, [cards, mode, favorites, activeCategory, searchQuery]);

  const visibleCards = useMemo(() => {
    if (mode === "favorites") {
      const favs = filteredCards;
      return [...favs].sort((a, b) => {
        const sa = stats.get(a.id);
        const sb = stats.get(b.id);
        const ra = sa ? sa.remembered - sa.forgotten : 0;
        const rb = sb ? sb.remembered - sb.forgotten : 0;
        return ra - rb;
      });
    }
    return filteredCards;
  }, [filteredCards, mode, stats]);

  const current = visibleCards[index % Math.max(1, visibleCards.length)];

  function nextCard() {
    setIndex((i) => (i + 1) % Math.max(1, visibleCards.length));
  }

  async function toggleFavorite(cardId: number) {
    const wasFav = favorites.has(cardId);
    const next = new Set(favorites);
    if (wasFav) next.delete(cardId);
    else next.add(cardId);
    setFavorites(next);
    try {
      const { getSessionId } = await import("@/lib/session");
      const sid = getSessionId();
      await fetch(`/api/favorites?sessionId=${sid}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cardId, favorite: !wasFav }),
      });
    } catch {
      /* ignore */
    }
  }

  async function handleToastFeedback(
    res: { newBadges: string[]; leveledUp: boolean; level: number } | null,
  ) {
    if (!res) return;
    if (res.leveledUp) setToastLevel(res.level);
    if (res.newBadges && res.newBadges.length > 0) {
      const code = res.newBadges[0];
      const def = BADGE_BY_CODE[code];
      if (def) {
        setToastBadge({
          code: def.code,
          title: def.title,
          emoji: def.emoji,
          gradient: def.gradient,
        });
      }
    }
  }

  async function handleWritingComplete() {
    setConfettiKey((k) => k + 1);
    const res = await award({ source: "flashcard", correct: true, delta: 10 });
    if (res) {
      await handleToastFeedback({
        newBadges: res.newBadges,
        leveledUp: res.leveledUp,
        level: res.level,
      });
    }
  }

  async function rate(card: DbCard, remembered: boolean) {
    if (remembered) setConfettiKey((k) => k + 1);
    setStats((s) => {
      const m = new Map(s);
      const cur = m.get(card.id) ?? { remembered: 0, forgotten: 0 };
      m.set(card.id, {
        remembered: cur.remembered + (remembered ? 1 : 0),
        forgotten: cur.forgotten + (remembered ? 0 : 1),
      });
      return m;
    });
    try {
      const { getSessionId } = await import("@/lib/session");
      await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: getSessionId(), cardId: card.id, remembered }),
      });
    } catch {
      /* ignore */
    }
    const res = await award({ source: "flashcard", correct: remembered });
    if (res) {
      await handleToastFeedback({
        newBadges: res.newBadges,
        leveledUp: res.leveledUp,
        level: res.level,
      });
    }
    if (remembered) {
      const newOnes = await checkCategoryMaster();
      if (newOnes && newOnes.length > 0) {
        const code = newOnes[0];
        const def = BADGE_BY_CODE[code];
        if (def) {
          setToastBadge({
            code: def.code,
            title: def.title,
            emoji: def.emoji,
            gradient: def.gradient,
          });
        }
      }
    }
    setTimeout(nextCard, 600);
  }

  function buildQuizQuestion(poolCards: DbCard[]): QuizQuestion {
    const ordered = shuffle(poolCards);
    const card = ordered[0];
    const others = shuffle(poolCards.filter((c) => c.id !== card.id)).slice(0, 3);
    const allChoices = shuffle([card, ...others]).map((c) => {
      const t = getTargetWord(c);
      return {
        label: t.script,
        sub: t.reading,
        cardId: c.id,
      };
    });
    return { card, options: allChoices };
  }

  function startQuiz() {
    if (filteredCards.length < 4) return;
    setQuiz(buildQuizQuestion(filteredCards));
    setQuizScore(0);
    setQuizTotal(0);
    setQuizStreak(0);
    setQuizBestStreak(0);
    setQuizFinished(false);
    setQuizFeedback(null);
    setQuizLastCard(null);
  }

  async function answerQuiz(chosenCardId: number) {
    if (!quiz) return;
    setQuizTotal((t) => t + 1);
    const correct = chosenCardId === quiz.card.id;
    if (correct) {
      setConfettiKey((k) => k + 1);
      setQuizScore((s) => s + 1);
      setQuizStreak((s) => {
        const next = s + 1;
        setQuizBestStreak((b) => Math.max(b, next));
        return next;
      });
    } else {
      setQuizStreak(0);
    }
    setQuizFeedback(correct ? "correct" : "wrong");
    setQuizLastCard(quiz.card);

    try {
      const { getSessionId } = await import("@/lib/session");
      await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: getSessionId(),
          cardId: quiz.card.id,
          remembered: correct,
        }),
      });
    } catch {
      /* ignore */
    }

    const res = await award({
      source: "quiz",
      correct,
      quizCorrectCount: correct ? quizScore + 1 : quizScore,
    });
    if (res) {
      await handleToastFeedback({
        newBadges: res.newBadges,
        leveledUp: res.leveledUp,
        level: res.level,
      });
    }

    setStats((s) => {
      const m = new Map(s);
      const cur = m.get(quiz.card.id) ?? { remembered: 0, forgotten: 0 };
      m.set(quiz.card.id, {
        remembered: cur.remembered + (correct ? 1 : 0),
        forgotten: cur.forgotten + (correct ? 0 : 1),
      });
      return m;
    });

    setTimeout(() => {
      if (filteredCards.length < 4) return;
      setQuiz(buildQuizQuestion(filteredCards));
      setQuizFeedback(null);
    }, 1000);
  }

  async function endQuiz() {
    setQuizFinished(true);
    setQuiz(null);
    if (quizBestStreak >= 5 && quizScore === quizTotal) {
      const res = await award({ source: "manual", perfectQuizSize: quizBestStreak });
      if (res) {
        await handleToastFeedback({
          newBadges: res.newBadges,
          leveledUp: res.leveledUp,
          level: res.level,
        });
      }
    }
  }

  const totalRemembered = Array.from(stats.values()).reduce((n, s) => n + s.remembered, 0);

  return (
    <div className="space-y-7">
      <ConfettiBurst trigger={confettiKey} />

      <LevelUpToast
        level={toastLevel}
        badgeCode={toastBadge?.code}
        badgeTitle={toastBadge?.title}
        badgeEmoji={toastBadge?.emoji}
        badgeGradient={toastBadge?.gradient}
        onDone={() => {
          setToastLevel(null);
          setToastBadge(null);
        }}
      />

      {/* BAR PILIH BAHASA CEPAT */}
      <div className="rounded-3xl bg-white/85 p-4 shadow-lg backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-wider text-pink-600">
              🌍 Bahasa yang Sedang Dipelajari
            </p>
            <p className="text-sm font-semibold text-slate-600">
              Klik tombol di bawah untuk mengganti bahasa, aksara, dan cara bacanya:
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {LANGUAGES.map((l) => {
              const active = l.code === language;
              return (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => {
                    setLanguage(l.code);
                    if (quiz && filteredCards.length >= 4) {
                      setQuiz(buildQuizQuestion(filteredCards));
                    }
                  }}
                  className={`flex items-center gap-2 rounded-2xl px-3.5 py-2 text-xs sm:text-sm font-extrabold transition ${
                    active
                      ? `bg-gradient-to-r ${l.gradient} text-white shadow-md scale-105 ring-2 ring-amber-300`
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  <span className="text-lg">{l.flag}</span>
                  <span>{l.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* STATS */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-gradient-to-br from-emerald-300 to-green-500 p-4 text-center text-white shadow-lg">
          <p className="text-3xl font-bold drop-shadow-md">{totalRemembered}</p>
          <p className="text-xs font-semibold uppercase tracking-wider opacity-90">Diingat</p>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-pink-300 to-rose-500 p-4 text-center text-white shadow-lg">
          <p className="text-3xl font-bold drop-shadow-md">{favorites.size}</p>
          <p className="text-xs font-semibold uppercase tracking-wider opacity-90">Favorit</p>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-amber-300 to-orange-500 p-4 text-center text-white shadow-lg">
          <p className="text-3xl font-bold drop-shadow-md">{cards.length}</p>
          <p className="text-xs font-semibold uppercase tracking-wider opacity-90">Total Kata</p>
        </div>
      </div>

      {/* MODE TABS */}
      <div className="glass rounded-2xl p-1.5 shadow-lg grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5">
        {(
          [
            { id: "flashcard", label: "Kartu Putar", emoji: "🎴" },
            { id: "writing", label: "Tulis & Baca", emoji: "✍️" },
            { id: "scriptguide", label: "Aksara & Nada", emoji: "📖" },
            { id: "match", label: "Cocok Gambar", emoji: "🧩" },
            { id: "quiz", label: "Kuis Seru", emoji: "🎯" },
            { id: "favorites", label: "Favorit", emoji: "❤️" },
          ] as { id: Mode; label: string; emoji: string }[]
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setMode(t.id)}
            className={`flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-bold transition ${
              mode === t.id
                ? "bg-gradient-to-r from-pink-400 via-orange-400 to-amber-400 text-white shadow-md"
                : "text-slate-700 hover:bg-white"
            }`}
          >
            <span className="text-lg">{t.emoji}</span>
            {t.label}
          </button>
        ))}
      </div>

      {/* SEARCH & CATEGORY FILTERS */}
      {(mode === "flashcard" || mode === "writing" || mode === "match" || mode === "quiz") && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[220px]">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIndex(0);
                }}
                placeholder={`🔍 Cari dari ${cards.length} kosakata (Indonesia, Inggris, Thai, Mandarin, Pinyin)...`}
                className="w-full rounded-2xl border-2 border-pink-200 bg-white/90 px-4 py-2.5 text-sm font-semibold text-slate-800 shadow-sm focus:border-pink-400 focus:outline-none"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery("");
                    setIndex(0);
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-slate-200 px-2 py-0.5 text-xs font-bold text-slate-700 hover:bg-slate-300"
                >
                  ✕
                </button>
              )}
            </div>
            {mode === "flashcard" && visibleCards.length > 1 && (
              <button
                type="button"
                onClick={() =>
                  setIndex(Math.floor(Math.random() * visibleCards.length))
                }
                className="rounded-2xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-2.5 text-xs sm:text-sm font-extrabold text-white shadow-md transition hover:scale-105"
              >
                🔀 Acak Kartu
              </button>
            )}
          </div>

          <div className="flex gap-2 overflow-x-auto scrollbar-hide py-1">
            <button
              type="button"
              onClick={() => {
                setActiveCategory("all");
                setIndex(0);
              }}
              className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold transition shadow-md ${
                activeCategory === "all"
                  ? "bg-slate-900 text-white ring-4 ring-amber-300"
                  : "bg-white text-slate-700 hover:bg-slate-100"
              }`}
            >
              ✨ Semua ({cards.length})
            </button>
            {allCategories.map((c, i) => {
              const info = CATEGORY_INFO[c];
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    setActiveCategory(c);
                    setIndex(0);
                  }}
                  style={{
                    background:
                      i % 2 === 0
                        ? "linear-gradient(135deg,#fb7185,#f472b6)"
                        : "linear-gradient(135deg,#60a5fa,#818cf8)",
                  }}
                  className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold text-white shadow-md transition hover:scale-105 ${
                    activeCategory === c ? "ring-4 ring-amber-300 scale-105" : ""
                  }`}
                >
                  {info ? `${info.emoji} ${info.label}` : c}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* MODE 1: FLASHCARD */}
      {mode === "flashcard" && (
        <div className="space-y-6">
          {current ? (
            <VocabCard
              key={current.id + "-" + index + "-" + language}
              emoji={current.emoji}
              indonesian={current.indonesian}
              english={current.english}
              pronunciation={current.pronunciation}
              gradient={current.gradient}
              exampleId={current.exampleId}
              exampleEn={current.exampleEn}
              thai={current.thai}
              thaiReading={current.thaiReading}
              thaiExample={current.thaiExample}
              thaiExampleReading={current.thaiExampleReading}
              chinese={current.chinese}
              chineseReading={current.chineseReading}
              chineseExample={current.chineseExample}
              chineseExampleReading={current.chineseExampleReading}
              onFavorite={() => toggleFavorite(current.id)}
              isFavorite={favorites.has(current.id)}
              onRate={(r) => rate(current, r)}
              onWritingComplete={handleWritingComplete}
            />
          ) : (
            <Mascot
              message="Belum ada kartu di kategori ini. Yuk pilih kategori lain!"
              emotion="thinking"
            />
          )}

          {current && (
            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() =>
                  setIndex((i) => (i - 1 + visibleCards.length) % visibleCards.length)
                }
                className="rounded-2xl bg-white px-5 py-3 font-bold text-slate-700 shadow-md transition hover:scale-105"
              >
                ← Sebelumnya
              </button>
              <span className="rounded-full bg-white/70 px-4 py-2 text-sm font-bold text-slate-700 backdrop-blur-md shadow">
                {(index % visibleCards.length) + 1} / {visibleCards.length}
              </span>
              <button
                type="button"
                onClick={nextCard}
                className="rounded-2xl bg-gradient-to-r from-orange-400 to-pink-500 px-5 py-3 font-bold text-white shadow-md transition hover:scale-105"
              >
                Berikutnya →
              </button>
            </div>
          )}

          <div className="rounded-2xl bg-white/75 p-4 text-center text-sm font-semibold text-slate-700 shadow-md backdrop-blur-md">
            💡 Tap kartu untuk membalik. Tekan <strong>✍️ Cara Tulis & Baca</strong> untuk latihan menulis aksara {langDef.label}!
          </div>
        </div>
      )}

      {/* MODE 2: STUDIO TULIS & BACA */}
      {mode === "writing" && (
        <div className="space-y-5">
          <div className="rounded-3xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 p-6 text-white shadow-xl">
            <h3 className="text-2xl font-black">
              ✍️ Studio Menulis & Membaca ({langDef.flag} {langDef.label})
            </h3>
            <p className="mt-1 text-sm font-medium opacity-95">
              Pelajari bentuk huruf/aksara, cara membacanya (Pinyin / Romanisasi / IPA), dengarkan suaranya, lalu klik <strong>Latihan Menulis</strong> untuk menggambar goresannya di atas kanvas!
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {visibleCards.map((c) => {
              const target = getTargetWord(c);
              return (
                <div
                  key={c.id}
                  className={`flex flex-col justify-between rounded-3xl bg-gradient-to-br ${c.gradient} p-5 text-white shadow-xl transition hover:-translate-y-1`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-5xl drop-shadow-md">{c.emoji}</span>
                      <span className="rounded-full bg-black/25 px-3 py-1 text-xs font-bold backdrop-blur-sm">
                        🇮🇩 {c.indonesian}
                      </span>
                    </div>

                    <div className="mt-4 rounded-2xl bg-white/20 p-3 text-center backdrop-blur-md">
                      <p className="text-[10px] font-bold uppercase tracking-wider opacity-85">
                        Aksara / Tulisan ({langDef.shortLabel})
                      </p>
                      <p className="mt-1 text-4xl font-black tracking-wide drop-shadow-sm">
                        {target.script}
                      </p>
                      {target.reading && (
                        <p className="mt-1 font-mono text-sm font-bold text-amber-100">
                          Cara Baca: {target.reading}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => speak(target.script, langDef.bcp47, { rate: 0.85 })}
                      className="flex-1 rounded-xl bg-white/25 px-3 py-2.5 text-xs font-extrabold text-white backdrop-blur-md transition hover:bg-white/40"
                    >
                      🔊 Dengar Bacaan
                    </button>
                    <button
                      type="button"
                      onClick={() => setPracticeCard(c)}
                      className="flex-1 rounded-xl bg-white px-3 py-2.5 text-xs font-extrabold text-slate-900 shadow-md transition hover:scale-105"
                    >
                      ✍️ Latihan Tulis
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODE 2B: PANDUAN AKSARA & NADA */}
      {mode === "scriptguide" && (
        <ScriptGuideView onEarnXp={handleWritingComplete} />
      )}

      {/* MODE 2C: GAME COCOK GAMBAR & AKSARA */}
      {mode === "match" && (
        <MemoryMatchGame
          cards={visibleCards.length >= 4 ? visibleCards : cards}
          onWinRound={async () => {
            setConfettiKey((k) => k + 1);
            const res = await award({ source: "quiz", correct: true, delta: 25 });
            if (res) {
              await handleToastFeedback({
                newBadges: res.newBadges,
                leveledUp: res.leveledUp,
                level: res.level,
              });
            }
          }}
        />
      )}

      {/* MODE 3: QUIZ */}
      {mode === "quiz" && (
        <div className="space-y-6">
          {!quiz && !quizFinished && (
            <div className="rounded-3xl bg-white p-8 text-center shadow-xl">
              <div className="mb-4 text-7xl animate-float">🎯</div>
              <h3 className="text-2xl font-bold text-slate-900">
                Kuis Bahasa {langDef.flag} {langDef.label}!
              </h3>
              <p className="mt-2 text-slate-600">
                Tebak kata & aksara <strong>{langDef.label}</strong> yang tepat dari gambar. Total{" "}
                {filteredCards.length} kata.
              </p>
              <button
                type="button"
                onClick={startQuiz}
                disabled={filteredCards.length < 4}
                className="mt-6 rounded-2xl bg-gradient-to-r from-pink-500 via-orange-400 to-amber-400 px-8 py-4 text-lg font-bold text-white shadow-lg transition hover:scale-105 disabled:cursor-not-allowed disabled:opacity-50"
              >
                🚀 Mulai Kuis ({langDef.shortLabel})
              </button>
            </div>
          )}

          {quiz && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <span className="rounded-full bg-white/70 px-4 py-1.5 text-sm font-bold text-slate-700 shadow">
                  Skor: {quizScore}/{quizTotal}
                </span>
                {quizStreak >= 2 && (
                  <span className="rounded-full bg-gradient-to-r from-orange-400 to-red-500 px-3 py-1 text-sm font-bold text-white shadow">
                    🔥 Streak {quizStreak}
                  </span>
                )}
                <button
                  type="button"
                  onClick={endQuiz}
                  className="rounded-full bg-rose-500 px-4 py-1.5 text-sm font-bold text-white shadow hover:bg-rose-600"
                >
                  Selesai
                </button>
              </div>

              <div
                className={`rounded-[36px] bg-gradient-to-br ${quiz.card.gradient} p-10 text-center text-white shadow-2xl`}
              >
                <span className="block text-[100px] drop-shadow-2xl">{quiz.card.emoji}</span>
                <p className="mt-2 text-sm font-semibold uppercase tracking-wider opacity-90">
                  Apa bahasa {langDef.label}-nya untuk:
                </p>
                <h3 className="mt-1 text-4xl font-bold drop-shadow-md">
                  {language === "id" ? quiz.card.english : quiz.card.indonesian}
                </h3>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {quiz.options.map((opt) => (
                  <button
                    key={opt.cardId}
                    type="button"
                    onClick={() => answerQuiz(opt.cardId)}
                    disabled={quizFeedback !== null}
                    className={`rounded-2xl px-4 py-5 text-center shadow-md transition ${
                      quizFeedback && opt.cardId === quizLastCard?.id
                        ? "bg-emerald-500 text-white"
                        : quizFeedback === "wrong" && opt.cardId !== quizLastCard?.id
                          ? "bg-white text-slate-700"
                          : "bg-white text-slate-800 hover:scale-105 hover:bg-amber-50"
                    } ${quizFeedback !== null ? "opacity-80" : ""}`}
                  >
                    <span className="block text-2xl font-black">{opt.label}</span>
                    {opt.sub && (
                      <span className="mt-1 block font-mono text-xs opacity-75">{opt.sub}</span>
                    )}
                  </button>
                ))}
              </div>

              {quizFeedback && quizLastCard && (
                <div
                  className={`animate-pop rounded-2xl p-4 text-center font-bold text-white shadow-lg ${
                    quizFeedback === "correct" ? "bg-emerald-500" : "bg-rose-500"
                  }`}
                >
                  {quizFeedback === "correct"
                    ? "🎉 Benar! +15 XP"
                    : `😅 Hampir! Jawaban: ${getTargetWord(quizLastCard).script} (${getTargetWord(quizLastCard).reading ?? ""})`}
                </div>
              )}
            </div>
          )}

          {quizFinished && (
            <div className="animate-pop rounded-3xl bg-gradient-to-br from-emerald-300 via-teal-400 to-cyan-500 p-8 text-center text-white shadow-2xl">
              <div className="text-7xl animate-wiggle">🏆</div>
              <h3 className="mt-4 text-3xl font-bold">Kuis Selesai!</h3>
              <p className="mt-2 text-5xl font-black">
                {quizScore}/{quizTotal}
              </p>
              <p className="text-lg font-semibold opacity-90">
                {quizScore === quizTotal && quizTotal > 0
                  ? "Sempurna! 🌟"
                  : quizScore > quizTotal / 2
                    ? "Hebat! Terus semangat! 💪"
                    : "Ayo coba lagi! 🌈"}
              </p>
              {quizBestStreak >= 3 && (
                <p className="mt-2 text-sm font-bold opacity-90">
                  🔥 Streak terbaik: {quizBestStreak}
                </p>
              )}
              <button
                type="button"
                onClick={startQuiz}
                className="mt-6 rounded-2xl bg-white px-8 py-3 font-bold text-slate-900 shadow-lg hover:scale-105"
              >
                🔁 Main Lagi
              </button>
            </div>
          )}
        </div>
      )}

      {/* MODE 4: FAVORITES */}
      {mode === "favorites" && (
        <div className="space-y-4">
          {visibleCards.length === 0 ? (
            <Mascot
              message="Belum ada kata favorit. Tekan ❤️ di kartu untuk menambahkannya!"
              emotion="thinking"
            />
          ) : (
            <>
              <p className="text-center text-sm font-semibold text-slate-600">
                {visibleCards.length} kata tersimpan ⭐
              </p>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {visibleCards.map((c) => {
                  const target = getTargetWord(c);
                  return (
                    <div
                      key={c.id}
                      onClick={() => {
                        setMode("flashcard");
                        setActiveCategory("all");
                        const idx = cards.findIndex((x) => x.id === c.id);
                        setIndex(idx >= 0 ? idx : 0);
                      }}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          setMode("flashcard");
                          setActiveCategory("all");
                          const idx = cards.findIndex((x) => x.id === c.id);
                          setIndex(idx >= 0 ? idx : 0);
                        }
                      }}
                      className={`group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-br ${c.gradient} p-4 text-left text-white shadow-lg transition hover:-translate-y-1 hover:shadow-2xl`}
                    >
                      <span className="block text-4xl drop-shadow-md transition group-hover:animate-wiggle">
                        {c.emoji}
                      </span>
                      <p className="mt-2 text-lg font-black drop-shadow-sm">{target.script}</p>
                      {target.reading && (
                        <p className="font-mono text-xs opacity-90">{target.reading}</p>
                      )}
                      <p className="text-xs font-medium opacity-90">🇮🇩 {c.indonesian}</p>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(c.id);
                        }}
                        className="absolute top-2 right-2 grid h-7 w-7 place-items-center rounded-full bg-white/30 text-sm backdrop-blur-md"
                        aria-label="Hapus favorit"
                      >
                        ❤️
                      </button>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      )}

      {/* Modal Latihan Menulis untuk Mode Studio Tulis & Baca */}
      {practiceCard && (
        <WritingPracticeModal
          open={true}
          onClose={() => setPracticeCard(null)}
          language={language}
          emoji={practiceCard.emoji}
          indonesian={practiceCard.indonesian}
          english={practiceCard.english}
          pronunciation={practiceCard.pronunciation}
          thai={practiceCard.thai}
          thaiReading={practiceCard.thaiReading}
          thaiExample={practiceCard.thaiExample}
          thaiExampleReading={practiceCard.thaiExampleReading}
          chinese={practiceCard.chinese}
          chineseReading={practiceCard.chineseReading}
          chineseExample={practiceCard.chineseExample}
          chineseExampleReading={practiceCard.chineseExampleReading}
          gradient={practiceCard.gradient}
          onCompletePractice={handleWritingComplete}
        />
      )}
    </div>
  );
}
