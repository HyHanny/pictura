"use client";

import { useXp } from "@/lib/useXp";
import { BADGES } from "@/lib/gamification";

type Props = {
  open: boolean;
  onClose: () => void;
};

export default function BadgeModal({ open, onClose }: Props) {
  const { badges } = useXp();
  const unlockedSet = new Set(badges.map((b) => b.code));

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-pop w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-2xl"
      >
        <div className="bg-gradient-to-r from-fuchsia-500 via-pink-500 to-orange-500 p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black">Koleksi Badge 🏅</h2>
              <p className="mt-1 text-sm opacity-90">
                {badges.length} / {BADGES.length} terbuka
              </p>
            </div>
            <button
              onClick={onClose}
              aria-label="Tutup"
              className="grid h-9 w-9 place-items-center rounded-full bg-white/30 text-lg font-bold backdrop-blur-md hover:bg-white/40"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-5">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {BADGES.map((b) => {
              const unlocked = unlockedSet.has(b.code);
              return (
                <div
                  key={b.code}
                  className={`relative overflow-hidden rounded-2xl p-4 text-center transition ${
                    unlocked
                      ? `bg-gradient-to-br ${b.gradient} text-white shadow-lg`
                      : "bg-slate-100 text-slate-400"
                  }`}
                >
                  <span
                    className={`block text-4xl drop-shadow-md ${unlocked ? "" : "grayscale opacity-60"}`}
                  >
                    {unlocked ? b.emoji : "🔒"}
                  </span>
                  <h3 className="mt-2 text-sm font-black">{b.title}</h3>
                  <p className="mt-1 text-[11px] font-medium opacity-90">{b.description}</p>
                  {unlocked ? (
                    <span className="mt-2 inline-block rounded-full bg-white/30 px-2 py-0.5 text-[10px] font-bold backdrop-blur-sm">
                      Terbuka ✓
                    </span>
                  ) : (
                    <span className="mt-2 inline-block rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-bold">
                      Belum
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
