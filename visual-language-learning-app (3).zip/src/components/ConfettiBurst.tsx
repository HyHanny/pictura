"use client";

import { useEffect, useState } from "react";

type Piece = {
  id: number;
  left: number;
  delay: number;
  rotate: number;
  emoji: string;
  size: number;
};

const EMOJIS = ["🎉", "⭐", "✨", "🎊", "💖", "🌟", "🍭", "🎈"];

export default function ConfettiBurst({ trigger }: { trigger: number }) {
  const [pieces, setPieces] = useState<Piece[]>([]);
  const [key, setKey] = useState(0);

  useEffect(() => {
    if (trigger === 0) return;
    setKey((k) => k + 1);
    const next: Piece[] = Array.from({ length: 26 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 0.4,
      rotate: Math.random() * 360,
      emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
      size: 20 + Math.random() * 18,
    }));
    setPieces(next);
    const t = setTimeout(() => setPieces([]), 1800);
    return () => clearTimeout(t);
  }, [trigger]);

  return (
    <div
      key={key}
      className="pointer-events-none fixed inset-0 z-50 overflow-hidden"
      aria-hidden
    >
      {pieces.map((p) => (
        <span
          key={p.id}
          className="absolute -top-10"
          style={{
            left: `${p.left}%`,
            animation: `confetti 1.5s ${p.delay}s ease-out forwards`,
            transform: `rotate(${p.rotate}deg)`,
            fontSize: `${p.size}px`,
          }}
        >
          {p.emoji}
        </span>
      ))}
    </div>
  );
}
