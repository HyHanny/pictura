"use client";

import { useState } from "react";
import { useLearn } from "@/lib/LearnContext";
import { speak } from "@/lib/speech";
import WritingPracticeModal from "./WritingPracticeModal";

const THAI_CONSONANTS = [
  { char: "ก", word: "ก ไก่", reading: "Ko Kai", meaning: "Ayam", emoji: "🐔", gradient: "from-amber-400 to-orange-500" },
  { char: "ข", word: "ข ไข่", reading: "Kho Khai", meaning: "Telur", emoji: "🥚", gradient: "from-yellow-400 to-amber-500" },
  { char: "ค", word: "ค ควาย", reading: "Kho Khwai", meaning: "Kerbau", emoji: "🐃", gradient: "from-slate-500 to-zinc-600" },
  { char: "ง", word: "ง งู", reading: "Ngo Ngu", meaning: "Ular", emoji: "🐍", gradient: "from-emerald-400 to-green-600" },
  { char: "จ", word: "จ จาน", reading: "Cho Chan", meaning: "Piring", emoji: "🍽️", gradient: "from-sky-400 to-blue-500" },
  { char: "ช", word: "ช ช้าง", reading: "Cho Chang", meaning: "Gajah", emoji: "🐘", gradient: "from-indigo-400 to-purple-500" },
  { char: "ต", word: "ต เต่า", reading: "To Tao", meaning: "Kura-kura", emoji: "🐢", gradient: "from-teal-400 to-emerald-600" },
  { char: "ป", word: "ป ปลา", reading: "Po Pla", meaning: "Ikan", emoji: "🐟", gradient: "from-cyan-400 to-blue-500" },
  { char: "ม", word: "ม ม้า", reading: "Mo Ma", meaning: "Kuda", emoji: "🐴", gradient: "from-orange-400 to-red-500" },
  { char: "ล", word: "ล ลิง", reading: "Lo Ling", meaning: "Monyet", emoji: "🐵", gradient: "from-amber-500 to-yellow-600" },
  { char: "ส", word: "ส เสือ", reading: "So Suea", meaning: "Harimau", emoji: "🐯", gradient: "from-orange-500 to-rose-500" },
  { char: "อ", word: "อ อ่าง", reading: "O Ang", meaning: "Mangkuk", emoji: "🥣", gradient: "from-pink-400 to-fuchsia-500" },
];

const THAI_VOWELS = [
  { symbol: "-ะ", sample: "กะ", reading: "a (pendek)", pos: "Di kanan konsonan", example: "มะระ (ma-ra)" },
  { symbol: "-า", sample: "กา", reading: "aa (panjang)", pos: "Di kanan konsonan", example: "ตา (taa = mata)" },
  { symbol: "-ิ", sample: "กิ", reading: "i (pendek)", pos: "Di atas konsonan", example: "กิน (kin = makan)" },
  { symbol: "-ี", sample: "กี", reading: "ii (panjang)", pos: "Di atas konsonan", example: "ดี (dii = bagus)" },
  { symbol: "-ุ", sample: "กุ", reading: "u (pendek)", pos: "Di bawah konsonan", example: "ถุง (thung = tas)" },
  { symbol: "-ู", sample: "กู", reading: "uu (panjang)", pos: "Di bawah konsonan", example: "งู (nguu = ular)" },
  { symbol: "เ-", sample: "เก", reading: "e (panjang)", pos: "Di depan konsonan!", example: "ทะเล (tha-le = laut)" },
  { symbol: "แ-", sample: "แก", reading: "ae (terbuka)", pos: "Di depan konsonan!", example: "แมว (maeo = kucing)" },
  { symbol: "โ-", sample: "โก", reading: "o (panjang)", pos: "Di depan konsonan!", example: "โต๊ะ (to = meja)" },
  { symbol: "ไ-", sample: "ไก", reading: "ai", pos: "Di depan konsonan!", example: "ไก่ (kai = ayam)" },
];

const CHINESE_TONES = [
  {
    tone: "Nada 1 (Datar Tinggi)",
    mark: "ā • ē • ī • ō • ū",
    contour: "─── (55)",
    sample: "妈",
    pinyin: "mā",
    meaning: "Ibu",
    emoji: "👩",
    color: "from-pink-400 to-rose-500",
    tip: "Suara tinggi dan rata seperti sedang bernyanyi satu nada panjang.",
  },
  {
    tone: "Nada 2 (Naik)",
    mark: "á • é • í • ó • ú",
    contour: "╱ (35)",
    sample: "茶",
    pinyin: "chá",
    meaning: "Teh",
    emoji: "🍵",
    color: "from-amber-400 to-orange-500",
    tip: "Suara naik dari tengah ke tinggi, mirip saat bertanya 'Hah? Apa?'",
  },
  {
    tone: "Nada 3 (Turun-Naik)",
    mark: "ǎ • ě • ǐ • ǒ • ǔ",
    contour: "╲╱ (214)",
    sample: "马",
    pinyin: "mǎ",
    meaning: "Kuda",
    emoji: "🐴",
    color: "from-emerald-400 to-teal-500",
    tip: "Suara mengayun turun ke rendah lalu naik lagi.",
  },
  {
    tone: "Nada 4 (Turun Tegas)",
    mark: "à • è • ì • ò • ù",
    contour: "╲ (51)",
    sample: "爸",
    pinyin: "bà",
    meaning: "Ayah",
    emoji: "👨",
    color: "from-sky-400 to-indigo-500",
    tip: "Suara turun cepat dan tegas dari tinggi ke rendah.",
  },
];

const CHINESE_PICTOGRAPHS = [
  { char: "口", pinyin: "kǒu", meaning: "Mulut", emoji: "👄", visualHint: "Bentuk kotak menyerupai mulut yang terbuka", gradient: "from-pink-400 to-rose-500" },
  { char: "人", pinyin: "rén", meaning: "Orang", emoji: "🚶", visualHint: "Dua kaki manusia yang sedang melangkah", gradient: "from-amber-400 to-orange-500" },
  { char: "木", pinyin: "mù", meaning: "Pohon / Kayu", emoji: "🌳", visualHint: "Batang pohon dengan dahan di atas dan akar di bawah", gradient: "from-emerald-400 to-green-600" },
  { char: "山", pinyin: "shān", meaning: "Gunung", emoji: "⛰️", visualHint: "Tiga puncak gunung yang menjulang", gradient: "from-teal-400 to-cyan-600" },
  { char: "水", pinyin: "shuǐ", meaning: "Air", emoji: "💧", visualHint: "Aliran sungai di tengah dengan percikan air di kiri-kanan", gradient: "from-sky-400 to-blue-600" },
  { char: "火", pinyin: "huǒ", meaning: "Api", emoji: "🔥", visualHint: "Lidah api yang berkobar ke atas", gradient: "from-orange-500 to-red-600" },
  { char: "日", pinyin: "rì", meaning: "Matahari", emoji: "☀️", visualHint: "Lingkaran matahari dengan titik cahaya di tengah", gradient: "from-yellow-400 to-amber-500" },
  { char: "月", pinyin: "yuè", meaning: "Bulan", emoji: "🌙", visualHint: "Lengkungan bulan sabit di langit malam", gradient: "from-indigo-400 to-purple-600" },
  { char: "门", pinyin: "mén", meaning: "Pintu", emoji: "🚪", visualHint: "Kusen daun pintu gerbang", gradient: "from-fuchsia-400 to-pink-600" },
  { char: "心", pinyin: "xīn", meaning: "Hati", emoji: "❤️", visualHint: "Lengkungan ruang jantung dan detaknya", gradient: "from-rose-400 to-red-500" },
  { char: "大", pinyin: "dà", meaning: "Besar", emoji: "🙆", visualHint: "Orang yang merentangkan kedua tangan dan kakinya lebar-lebar", gradient: "from-violet-400 to-indigo-600" },
  { char: "目", pinyin: "mù", meaning: "Mata", emoji: "👁️", visualHint: "Kelopak mata dengan bola mata di dalamnya", gradient: "from-cyan-400 to-teal-600" },
];

type PracticeTarget = {
  script: string;
  reading: string;
  meaning: string;
  emoji: string;
  gradient: string;
  lang: "th" | "zh" | "en";
};

export default function ScriptGuideView({ onEarnXp }: { onEarnXp?: () => void }) {
  const { language, setLanguage, speechRate } = useLearn();
  const [practiceItem, setPracticeItem] = useState<PracticeTarget | null>(null);

  const activeTab = language === "th" || language === "zh" ? language : "th";

  return (
    <div className="space-y-6">
      {/* PILIH PANDUAN AKSARA */}
      <div className="rounded-3xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 p-6 text-white shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="inline-block rounded-full bg-white/20 px-3 py-1 text-xs font-extrabold uppercase tracking-wider">
              📖 Rahasia Cepat Hafal Aksara & Cara Baca
            </span>
            <h2 className="mt-2 text-2xl sm:text-3xl font-black">
              Panduan Menulis & Membaca Bahasa Asing
            </h2>
            <p className="mt-1 text-sm opacity-95">
              Gunakan asosiasi gambar, dengarkan bunyi nadanya, lalu coba tulis langsung di kanvas!
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setLanguage("th")}
              className={`rounded-2xl px-4 py-2.5 text-sm font-extrabold transition ${
                activeTab === "th"
                  ? "bg-white text-purple-700 shadow-lg scale-105"
                  : "bg-white/20 text-white hover:bg-white/30"
              }`}
            >
              🇹🇭 Aksara Thailand (ไทย)
            </button>
            <button
              type="button"
              onClick={() => setLanguage("zh")}
              className={`rounded-2xl px-4 py-2.5 text-sm font-extrabold transition ${
                activeTab === "zh"
                  ? "bg-white text-rose-600 shadow-lg scale-105"
                  : "bg-white/20 text-white hover:bg-white/30"
              }`}
            >
              🇨🇳 Mandarin Hanzi & Pinyin (中文)
            </button>
          </div>
        </div>
      </div>

      {/* PANDUAN THAILAND */}
      {activeTab === "th" && (
        <div className="space-y-6">
          {/* Aturan Emas Menulis Thai */}
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl bg-gradient-to-br from-amber-200 to-orange-300 p-4 text-slate-900 shadow-md">
              <span className="text-3xl">🌀</span>
              <h4 className="mt-2 font-black">1. Mulai dari Lingkaran Kepala</h4>
              <p className="mt-1 text-xs font-medium">
                Hampir semua huruf Thailand punya lingkaran kecil (หัว / hua). Selalu mulai menulis dari lingkaran itu lalu tarik garis dalam 1 tarikan!
              </p>
            </div>
            <div className="rounded-2xl bg-gradient-to-br from-pink-200 to-rose-300 p-4 text-slate-900 shadow-md">
              <span className="text-3xl">🧭</span>
              <h4 className="mt-2 font-black">2. Vokal di 4 Arah</h4>
              <p className="mt-1 text-xs font-medium">
                Vokal Thailand bisa dipasang di depan (เ-, แ-), di atas (-ิ, -ี), di bawah (-ุ, -ู), atau di kanan (-ะ, -า) huruf konsonan.
              </p>
            </div>
            <div className="rounded-2xl bg-gradient-to-br from-sky-200 to-indigo-300 p-4 text-slate-900 shadow-md">
              <span className="text-3xl">🐔</span>
              <h4 className="mt-2 font-black">3. Hafal Lewat Gambar Hewan/Benda</h4>
              <p className="mt-1 text-xs font-medium">
                Di Thailand, setiap huruf punya nama benda pendamping, misalnya <strong>ก ไก่ (Ko Kai = Ayam)</strong> agar mudah diingat!
              </p>
            </div>
          </div>

          {/* 12 Konsonan Utama Thailand dengan Gambar */}
          <div className="rounded-3xl bg-white/85 p-5 shadow-xl backdrop-blur-md">
            <h3 className="text-xl font-black text-slate-900">
              🇹🇭 12 Huruf Konsonan Utama Thailand (Metode Gambar)
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Klik <strong>🔊 Bunyi</strong> untuk mendengar pelafalan asli, atau <strong>✍️ Tulis</strong> untuk berlatih menggambar hurufnya:
            </p>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {THAI_CONSONANTS.map((item) => (
                <div
                  key={item.char}
                  className={`flex flex-col justify-between rounded-2xl bg-gradient-to-br ${item.gradient} p-4 text-white shadow-lg transition hover:-translate-y-1`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-4xl drop-shadow">{item.emoji}</span>
                    <span className="rounded-full bg-black/25 px-2.5 py-0.5 text-[11px] font-bold">
                      {item.meaning}
                    </span>
                  </div>

                  <div className="my-3 text-center">
                    <p className="text-5xl font-black drop-shadow-md">{item.char}</p>
                    <p className="mt-1 text-sm font-extrabold">{item.word}</p>
                    <p className="font-mono text-xs text-amber-100">{item.reading}</p>
                  </div>

                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => speak(item.word, "th-TH", { rate: speechRate })}
                      className="flex-1 rounded-xl bg-white/25 py-1.5 text-xs font-bold text-white hover:bg-white/40"
                    >
                      🔊 Bunyi
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setPracticeItem({
                          script: item.char,
                          reading: `${item.word} (${item.reading})`,
                          meaning: item.meaning,
                          emoji: item.emoji,
                          gradient: item.gradient,
                          lang: "th",
                        })
                      }
                      className="flex-1 rounded-xl bg-white py-1.5 text-xs font-extrabold text-slate-900 shadow hover:scale-105"
                    >
                      ✍️ Tulis
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tabel Vokal Thailand */}
          <div className="rounded-3xl bg-white/85 p-5 shadow-xl backdrop-blur-md">
            <h3 className="text-xl font-black text-slate-900">
              🔤 Cara Membaca Huruf Vokal Thailand (สระ)
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Tanda strip (-) menunjukkan posisi huruf konsonan (contoh menggunakan huruf ก = k):
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
              {THAI_VOWELS.map((v) => (
                <button
                  key={v.symbol}
                  type="button"
                  onClick={() => speak(v.sample, "th-TH", { rate: speechRate })}
                  className="flex flex-col items-center rounded-2xl border-2 border-purple-200 bg-gradient-to-b from-purple-50 to-pink-50 p-3 text-center transition hover:scale-105 hover:border-pink-400"
                >
                  <span className="text-3xl font-black text-purple-900">{v.sample}</span>
                  <span className="mt-1 rounded-full bg-purple-200 px-2 py-0.5 font-mono text-xs font-bold text-purple-900">
                    {v.reading}
                  </span>
                  <span className="mt-1 text-[10px] font-bold text-slate-500">{v.pos}</span>
                  <span className="mt-1 text-[11px] font-semibold text-pink-700">{v.example}</span>
                  <span className="mt-1.5 text-[10px] font-extrabold text-purple-600">
                    🔊 Klik Dengar
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANDUAN MANDARIN / CHINA */}
      {activeTab === "zh" && (
        <div className="space-y-6">
          {/* 4 Nada Mandarin */}
          <div className="rounded-3xl bg-white/85 p-5 shadow-xl backdrop-blur-md">
            <h3 className="text-xl font-black text-slate-900">
              🎵 4 Nada Utama Bahasa Mandarin (Pinyin Tones)
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Dalam bahasa China, beda nada = beda arti! Klik tombol suara untuk mendengar perbedaannya:
            </p>

            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {CHINESE_TONES.map((t) => (
                <div
                  key={t.tone}
                  className={`flex flex-col justify-between rounded-2xl bg-gradient-to-br ${t.color} p-4 text-white shadow-lg`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-3xl">{t.emoji}</span>
                      <span className="rounded-full bg-black/25 px-2.5 py-0.5 font-mono text-xs font-bold">
                        {t.contour}
                      </span>
                    </div>
                    <h4 className="mt-2 text-sm font-black">{t.tone}</h4>
                    <p className="font-mono text-xs opacity-90">{t.mark}</p>

                    <div className="my-3 rounded-xl bg-white/20 p-2.5 text-center backdrop-blur-sm">
                      <p className="text-4xl font-black">{t.sample}</p>
                      <p className="font-mono text-sm font-bold">{t.pinyin}</p>
                      <p className="text-xs font-semibold">Arti: {t.meaning}</p>
                    </div>

                    <p className="text-[11px] leading-snug opacity-95">{t.tip}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => speak(t.sample, "zh-CN", { rate: speechRate })}
                    className="mt-3 w-full rounded-xl bg-white py-2 text-xs font-extrabold text-slate-900 shadow hover:scale-105"
                  >
                    🔊 Dengar Nada ({t.pinyin})
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* 12 Karakter Hanzi dari Gambar (Pictographs) */}
          <div className="rounded-3xl bg-white/85 p-5 shadow-xl backdrop-blur-md">
            <h3 className="text-xl font-black text-slate-900">
              🇨🇳 12 Huruf Hanzi Dasar dari Gambar (Piktograf)
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Huruf Mandarin awalnya berasal dari gambar benda nyata! Hafalkan bentuk visualnya lalu latih tulisannya:
            </p>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {CHINESE_PICTOGRAPHS.map((item) => (
                <div
                  key={item.char}
                  className={`flex flex-col justify-between rounded-2xl bg-gradient-to-br ${item.gradient} p-4 text-white shadow-lg transition hover:-translate-y-1`}
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <span className="text-4xl drop-shadow">{item.emoji}</span>
                      <span className="rounded-full bg-black/25 px-2.5 py-0.5 text-[11px] font-bold">
                        {item.meaning}
                      </span>
                    </div>

                    <div className="my-3 text-center">
                      <p className="text-5xl font-black drop-shadow-md">{item.char}</p>
                      <p className="mt-1 font-mono text-sm font-extrabold text-amber-100">
                        {item.pinyin}
                      </p>
                    </div>

                    <p className="rounded-xl bg-black/15 p-2 text-[11px] leading-snug">
                      💡 {item.visualHint}
                    </p>
                  </div>

                  <div className="mt-3 flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => speak(item.char, "zh-CN", { rate: speechRate })}
                      className="flex-1 rounded-xl bg-white/25 py-1.5 text-xs font-bold text-white hover:bg-white/40"
                    >
                      🔊 Bunyi
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setPracticeItem({
                          script: item.char,
                          reading: item.pinyin,
                          meaning: item.meaning,
                          emoji: item.emoji,
                          gradient: item.gradient,
                          lang: "zh",
                        })
                      }
                      className="flex-1 rounded-xl bg-white py-1.5 text-xs font-extrabold text-slate-900 shadow hover:scale-105"
                    >
                      ✍️ Tulis
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {practiceItem && (
        <WritingPracticeModal
          open={true}
          onClose={() => setPracticeItem(null)}
          language={practiceItem.lang}
          emoji={practiceItem.emoji}
          indonesian={practiceItem.meaning}
          english={practiceItem.meaning}
          pronunciation={practiceItem.reading}
          thai={practiceItem.lang === "th" ? practiceItem.script : null}
          thaiReading={practiceItem.lang === "th" ? practiceItem.reading : null}
          thaiExample={null}
          thaiExampleReading={null}
          chinese={practiceItem.lang === "zh" ? practiceItem.script : null}
          chineseReading={practiceItem.lang === "zh" ? practiceItem.reading : null}
          chineseExample={null}
          chineseExampleReading={null}
          gradient={practiceItem.gradient}
          onCompletePractice={onEarnXp}
        />
      )}
    </div>
  );
}
