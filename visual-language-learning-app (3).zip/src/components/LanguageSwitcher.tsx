"use client";

import { useState } from "react";
import { useLearn } from "@/lib/LearnContext";

export default function LanguageSwitcher() {
  const { language, setLanguage, available } = useLearn();
  const [open, setOpen] = useState(false);
  const current = available.find((l) => l.code === language) ?? available[1];

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        className={`flex items-center gap-2 rounded-full bg-gradient-to-r ${current.gradient} px-4 py-2 text-sm font-bold text-white shadow-lg transition hover:scale-105 active:scale-95`}
      >
        <span className="text-lg leading-none">{current.flag}</span>
        <span className="font-mono tracking-wide">{current.shortLabel}</span>
        <span className={`text-xs transition-transform ${open ? "rotate-180" : ""}`}>▾</span>
      </button>

      {open && (
        <>
          <button
            type="button"
            aria-label="Tutup menu bahasa"
            className="fixed inset-0 z-30 cursor-default"
            onClick={() => setOpen(false)}
          />
          <div
            role="listbox"
            className="animate-pop absolute right-0 z-40 mt-2 w-60 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl"
          >
            <div className="bg-gradient-to-r from-violet-500 via-fuchsia-500 to-amber-400 p-3 text-white">
              <p className="text-[10px] font-bold uppercase tracking-wider opacity-90">
                Bahasa Target
              </p>
              <p className="text-base font-black">{current.label}</p>
            </div>
            <ul className="max-h-72 overflow-y-auto py-1.5">
              {available.map((l) => {
                const active = l.code === language;
                return (
                  <li key={l.code}>
                    <button
                      type="button"
                      role="option"
                      aria-selected={active}
                      onClick={() => {
                        setLanguage(l.code);
                        setOpen(false);
                      }}
                      className={`flex w-full items-center gap-3 px-3 py-2.5 text-left transition ${
                        active
                          ? "bg-gradient-to-r from-pink-50 to-amber-50"
                          : "hover:bg-slate-50"
                      }`}
                    >
                      <span className="text-2xl">{l.flag}</span>
                      <div className="flex-1">
                        <p className="text-sm font-black text-slate-900">{l.label}</p>
                        <p className="text-[11px] font-mono font-medium text-slate-500">
                          {l.bcp47}
                        </p>
                      </div>
                      {active && (
                        <span className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-pink-500 to-orange-500 text-xs font-bold text-white shadow">
                          ✓
                        </span>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
            <div className="border-t border-slate-100 bg-slate-50 px-3 py-2 text-[10px] font-medium text-slate-500">
              🔉 Pelafalan mengikuti bahasa yang dipilih
            </div>
          </div>
        </>
      )}
    </div>
  );
}
