"use client";

import { useEffect, useState } from "react";

type Props = {
  /** Pass level to show toast; null hides it. */
  level: number | null;
  badgeCode?: string;
  badgeTitle?: string;
  badgeEmoji?: string;
  badgeGradient?: string;
  onDone?: () => void;
};

export default function LevelUpToast({ level, badgeCode, badgeTitle, badgeEmoji, badgeGradient, onDone }: Props) {
  const [visible, setVisible] = useState(false);
  const [content, setContent] = useState<Props | null>(null);

  useEffect(() => {
    if (level === null && !badgeCode) {
      setVisible(false);
      return;
    }
    setVisible(true);
    setContent({ level, badgeCode, badgeTitle, badgeEmoji, badgeGradient });
    const t = setTimeout(() => {
      setVisible(false);
      onDone?.();
    }, 3200);
    return () => clearTimeout(t);
  }, [level, badgeCode, badgeTitle, badgeEmoji, badgeGradient, onDone]);

  if (!visible || !content) return null;

  if (content.badgeCode) {
    return (
      <div className="fixed top-4 left-1/2 z-[60] -translate-x-1/2 animate-pop">
        <div
          className={`flex items-center gap-3 rounded-2xl bg-gradient-to-r ${content.badgeGradient ?? "from-amber-400 to-pink-500"} px-5 py-3 text-white shadow-2xl`}
        >
          <span className="text-4xl drop-shadow-lg">{content.badgeEmoji}</span>
          <div>
            <p className="text-xs font-bold uppercase tracking-wider opacity-90">
              Badge Terbuka!
            </p>
            <p className="text-lg font-black">{content.badgeTitle}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed top-4 left-1/2 z-[60] -translate-x-1/2 animate-pop">
      <div className="flex items-center gap-3 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-pink-500 px-5 py-3 text-white shadow-2xl">
        <span className="text-4xl drop-shadow-lg">🎉</span>
        <div>
          <p className="text-xs font-bold uppercase tracking-wider opacity-90">Naik Level!</p>
          <p className="text-lg font-black">Kamu sekarang Level {content.level}</p>
        </div>
      </div>
    </div>
  );
}
