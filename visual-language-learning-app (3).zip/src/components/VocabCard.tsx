"use client";

import { useMemo, useState } from "react";
import SpeakerButton from "./SpeakerButton";
import WritingPracticeModal from "./WritingPracticeModal";
import { speak, stopSpeaking } from "@/lib/speech";
import { useLearn } from "@/lib/LearnContext";
import { LANGUAGE_BY_CODE } from "@/lib/languages";
import type { LanguageCode } from "@/lib/languages";

type DbCardFields = {
  indonesian: string;
  english: string;
  pronunciation: string;
  thai: string | null;
  thaiReading: string | null;
  thaiExample: string | null;
  thaiExampleReading: string | null;
  chinese: string | null;
  chineseReading: string | null;
  chineseExample: string | null;
  chineseExampleReading: string | null;
  exampleId: string | null;
  exampleEn: string | null;
};

type Props = DbCardFields & {
  emoji: string;
  gradient: string;
  onRate?: (remembered: boolean) => void;
  onFavorite?: () => void;
  isFavorite?: boolean;
  onWritingComplete?: () => void;
};

function getCardText(
  code: LanguageCode,
  card: DbCardFields,
): {
  front: string;
  reading: string | null;
  readingLabel: string;
  example: string | null;
  exampleReading: string | null;
  back: string;
  backExample: string | null;
} | null {
  const indonesian = card.indonesian;
  switch (code) {
    case "id":
      return {
        front: indonesian,
        reading: card.pronunciation,
        readingLabel: "Ejaan Indonesia",
        example: card.exampleId,
        exampleReading: null,
        back: card.english,
        backExample: card.exampleEn,
      };
    case "en":
      return {
        front: card.english,
        reading: card.pronunciation,
        readingLabel: "Cara Baca (IPA)",
        example: card.exampleEn,
        exampleReading: null,
        back: indonesian,
        backExample: card.exampleId,
      };
    case "th":
      if (!card.thai) return null;
      return {
        front: card.thai,
        reading: card.thaiReading,
        readingLabel: "Cara Baca (Romanisasi Thai)",
        example: card.thaiExample,
        exampleReading: card.thaiExampleReading,
        back: indonesian,
        backExample: card.exampleId,
      };
    case "zh":
      if (!card.chinese) return null;
      return {
        front: card.chinese,
        reading: card.chineseReading,
        readingLabel: "Cara Baca (Pinyin & Nada)",
        example: card.chineseExample,
        exampleReading: card.chineseExampleReading,
        back: indonesian,
        backExample: card.exampleId,
      };
    default:
      return null;
  }
}

export default function VocabCard(props: Props) {
  const {
    emoji,
    indonesian,
    english,
    pronunciation,
    thai,
    thaiReading,
    thaiExample,
    thaiExampleReading,
    chinese,
    chineseReading,
    chineseExample,
    chineseExampleReading,
    exampleId,
    exampleEn,
    gradient,
    onRate,
    onFavorite,
    isFavorite,
    onWritingComplete,
  } = props;

  const { language, speechRate, autoSpeak, showReadingOnFront } = useLearn();
  const lang = LANGUAGE_BY_CODE[language];
  const cardData = useMemo(() => {
    const all: DbCardFields = {
      indonesian,
      english,
      pronunciation,
      thai,
      thaiReading,
      thaiExample,
      thaiExampleReading,
      chinese,
      chineseReading,
      chineseExample,
      chineseExampleReading,
      exampleId,
      exampleEn,
    };
    return getCardText(language, all);
  }, [
    language,
    indonesian,
    english,
    pronunciation,
    thai,
    thaiReading,
    thaiExample,
    thaiExampleReading,
    chinese,
    chineseReading,
    chineseExample,
    chineseExampleReading,
    exampleId,
    exampleEn,
  ]);

  const [flipped, setFlipped] = useState(false);
  const [playingExample, setPlayingExample] = useState<"front" | "back" | null>(null);
  const [writingOpen, setWritingOpen] = useState(false);

  function play(which: "front" | "back", text: string | null) {
    if (!text) return;
    if (playingExample) stopSpeaking();
    const bcp47 = which === "front" ? lang.bcp47 : "id-ID";
    setPlayingExample(which);
    speak(text, bcp47, { rate: speechRate });
    setTimeout(() => setPlayingExample(null), 5000);
  }

  if (!cardData) {
    return (
      <div
        className={`relative mx-auto w-full max-w-sm rounded-[36px] bg-gradient-to-br ${gradient} p-10 text-center text-white shadow-2xl`}
      >
        <div className="text-7xl">{emoji}</div>
        <p className="mt-3 text-2xl font-bold">{indonesian}</p>
        <p className="mt-2 text-sm opacity-90">
          🚧 Belum ada data untuk bahasa {lang.label}
        </p>
      </div>
    );
  }

  const { front, reading, readingLabel, example, exampleReading, back, backExample } = cardData;

  return (
    <>
      <div className="card-3d w-full max-w-sm mx-auto">
        <div
          className={`card-3d-inner ${flipped ? "flipped" : ""} relative h-[520px] w-full rounded-[36px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)]`}
        >
          {/* FRONT — target language (uses div[role=button] so inner buttons are valid HTML) */}
          <div
            role="button"
            tabIndex={0}
            onClick={() => {
              setFlipped(true);
              if (autoSpeak) {
                speak(front, lang.bcp47, { rate: speechRate });
              }
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                setFlipped(true);
                if (autoSpeak) {
                  speak(front, lang.bcp47, { rate: speechRate });
                }
              }
            }}
            aria-label="Tap untuk melihat terjemahan"
            className={`card-face absolute inset-0 flex cursor-pointer flex-col items-center justify-center rounded-[36px] bg-gradient-to-br ${gradient} p-8 text-white select-none`}
          >
            <div className="absolute inset-0 rounded-[36px] bg-white/10 opacity-50" />
            <div className="absolute -top-6 -right-6 h-32 w-32 rounded-full bg-white/30 blur-2xl" />
            <div className="absolute -bottom-6 -left-6 h-32 w-32 rounded-full bg-black/10 blur-2xl" />

            <span className="absolute top-4 left-4 rounded-full bg-black/30 px-3 py-1 text-xs font-bold backdrop-blur-md">
              {lang.flag} {lang.label}
            </span>

            <div className="relative z-10 flex flex-col items-center gap-3 text-center">
              <span className="text-[110px] leading-none drop-shadow-2xl">{emoji}</span>
              <h2
                className={`font-bold tracking-tight drop-shadow-md ${
                  language === "zh" ? "text-6xl leading-tight" : "text-5xl"
                }`}
              >
                {front}
              </h2>
              {reading && showReadingOnFront && (
                <div className="rounded-2xl bg-black/20 px-4 py-1.5 backdrop-blur-sm">
                  <p className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                    {readingLabel}
                  </p>
                  <p className="font-mono text-lg font-bold">{reading}</p>
                </div>
              )}
              <span className="mt-1 text-xs font-semibold opacity-90">
                Tap kartu untuk balik arti & contoh ✨
              </span>
            </div>

            <div
              className="absolute bottom-5 left-5 right-5 z-20 flex items-center justify-between"
              onClick={(e) => e.stopPropagation()}
            >
              <SpeakerButton
                text={front}
                lang={lang.bcp47}
                size="md"
                label={`kata ${lang.shortLabel}`}
              />

              <button
                type="button"
                onClick={() => setWritingOpen(true)}
                className="flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-extrabold text-slate-900 shadow-lg transition hover:scale-105 active:scale-95"
              >
                ✍️ Cara Tulis & Baca
              </button>
            </div>

            {onFavorite && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onFavorite();
                }}
                className="absolute top-4 right-4 z-20 grid h-11 w-11 place-items-center rounded-full bg-white/30 backdrop-blur-md transition active:scale-90 hover:bg-white/50"
                aria-label="Favorit"
              >
                <span className="text-lg">{isFavorite ? "❤️" : "🤍"}</span>
              </button>
            )}
          </div>

          {/* BACK — Indonesian + English reference */}
          <div
            className={`card-face card-face-back flex flex-col items-center justify-center overflow-y-auto rounded-[36px] bg-gradient-to-br ${gradient} p-6 text-white`}
          >
            <div className="absolute inset-0 rounded-[36px] bg-black/25" />
            <div className="absolute top-6 right-6 h-24 w-24 rounded-full bg-white/20 blur-2xl" />
            <div className="absolute bottom-6 left-6 h-24 w-24 rounded-full bg-white/20 blur-2xl" />

            <span className="absolute top-4 left-4 rounded-full bg-black/30 px-2.5 py-1 text-[10px] font-bold backdrop-blur-md">
              {lang.flag} {front} {reading ? `(${reading})` : ""}
            </span>

            <div className="relative z-10 flex w-full flex-col items-center gap-2.5 text-center mt-4">
              <span className="text-5xl drop-shadow-2xl">{emoji}</span>

              <div className="grid w-full grid-cols-2 gap-2">
                <div className="rounded-2xl bg-white/20 px-3 py-2 backdrop-blur-md">
                  <p className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                    🇮🇩 Indonesia
                  </p>
                  <h3 className="text-xl font-extrabold drop-shadow-md">{indonesian}</h3>
                </div>

                <div className="rounded-2xl bg-white/20 px-3 py-2 backdrop-blur-md">
                  <p className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                    🇬🇧 English
                  </p>
                  <p className="text-xl font-extrabold drop-shadow-sm">{english}</p>
                  <p className="font-mono text-[11px] italic opacity-90">{pronunciation}</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <SpeakerButton
                  text={front}
                  lang={lang.bcp47}
                  size="sm"
                  label={`ulang kata ${lang.shortLabel}`}
                />
                <button
                  type="button"
                  onClick={() => setWritingOpen(true)}
                  className="flex items-center gap-1 rounded-full bg-amber-300 px-3 py-1.5 text-[11px] font-extrabold text-slate-900 shadow transition hover:scale-105"
                >
                  ✍️ Latihan Tulis
                </button>
                {example && (
                  <button
                    type="button"
                    onClick={() => play("front", example)}
                    className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                      playingExample === "front"
                        ? "bg-white text-slate-900"
                        : "bg-white/25 backdrop-blur-md hover:bg-white/40"
                    }`}
                  >
                    🔈 {lang.shortLabel} contoh
                  </button>
                )}
                {backExample && (
                  <button
                    type="button"
                    onClick={() => play("back", backExample)}
                    className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                      playingExample === "back"
                        ? "bg-white text-slate-900"
                        : "bg-white/25 backdrop-blur-md hover:bg-white/40"
                    }`}
                  >
                    🔈 ID contoh
                  </button>
                )}
              </div>

              {(example || exampleReading) && (
                <div className="mt-1 w-full rounded-2xl bg-white/15 p-3 text-left backdrop-blur-md">
                  <p className="text-[10px] font-bold uppercase tracking-wider opacity-90">
                    Contoh Kalimat & Cara Baca
                  </p>
                  {example && (
                    <p
                      className={`mt-1 font-semibold ${
                        language === "zh" ? "text-base leading-snug" : "text-sm"
                      }`}
                    >
                      {example}
                    </p>
                  )}
                  {exampleReading && (
                    <p className="font-mono text-xs italic text-amber-200">{exampleReading}</p>
                  )}
                  {backExample && (
                    <p className="mt-1.5 border-t border-white/20 pt-1.5 text-[11px] italic opacity-90">
                      🇮🇩 {backExample}
                    </p>
                  )}
                </div>
              )}

              <div className="mt-1 flex gap-2">
                {onRate && (
                  <>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRate(false);
                      }}
                      className="rounded-2xl bg-white/30 px-4 py-2.5 text-sm font-semibold backdrop-blur-md transition hover:bg-white/50 active:scale-95"
                    >
                      😵 Lupa
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRate(true);
                      }}
                      className="rounded-2xl bg-white px-4 py-2.5 text-sm font-bold text-slate-900 shadow-lg transition hover:scale-105 active:scale-95"
                    >
                      ✨ Ingat!
                    </button>
                  </>
                )}
              </div>

              <button
                type="button"
                onClick={() => setFlipped(false)}
                className="mt-1 text-[11px] font-medium opacity-80 underline-offset-4 hover:underline"
              >
                Kembali ↺
              </button>
            </div>
          </div>
        </div>
      </div>

      <WritingPracticeModal
        open={writingOpen}
        onClose={() => setWritingOpen(false)}
        language={language}
        emoji={emoji}
        indonesian={indonesian}
        english={english}
        pronunciation={pronunciation}
        thai={thai}
        thaiReading={thaiReading}
        thaiExample={thaiExample}
        thaiExampleReading={thaiExampleReading}
        chinese={chinese}
        chineseReading={chineseReading}
        chineseExample={chineseExample}
        chineseExampleReading={chineseExampleReading}
        gradient={gradient}
        onCompletePractice={onWritingComplete}
      />
    </>
  );
}
