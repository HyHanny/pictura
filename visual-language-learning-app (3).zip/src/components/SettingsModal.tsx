"use client";

import { useLearn, THEME_MOODS } from "@/lib/LearnContext";
import { LANGUAGES, LANGUAGE_BY_CODE } from "@/lib/languages";
import { speak } from "@/lib/speech";

type Props = {
  open: boolean;
  onClose: () => void;
};

const TEST_PHRASES: Record<string, { text: string; reading: string }> = {
  en: { text: "Hello! Learning is fun!", reading: "/həˈloʊ/" },
  th: { text: "สวัสดี", reading: "sa-wat-dee" },
  zh: { text: "你好", reading: "nǐ hǎo" },
  id: { text: "Halo! Semangat belajar!", reading: "ha-lo" },
};

export default function SettingsModal({ open, onClose }: Props) {
  const {
    language,
    setLanguage,
    speechRate,
    setSpeechRate,
    autoSpeak,
    setAutoSpeak,
    showReadingOnFront,
    setShowReadingOnFront,
    themeMood,
    setThemeMood,
  } = useLearn();

  if (!open) return null;

  const currentLang = LANGUAGE_BY_CODE[language];
  const sample = TEST_PHRASES[language] ?? TEST_PHRASES.en;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-pop my-auto w-full max-w-2xl overflow-hidden rounded-[32px] bg-white shadow-2xl"
      >
        {/* HEADER */}
        <div className="bg-gradient-to-r from-pink-500 via-orange-400 to-amber-400 p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black">⚙️ Pengaturan Belajar & Bahasa</h2>
              <p className="mt-0.5 text-sm font-medium opacity-95">
                Sesuaikan bahasa, cara baca aksara, suara, dan tema warna anti-ngantuk
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="grid h-10 w-10 place-items-center rounded-full bg-white/25 text-lg font-bold text-white hover:bg-white/40"
              aria-label="Tutup pengaturan"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="max-h-[78vh] space-y-6 overflow-y-auto p-5 sm:p-6">
          {/* 1. PILIH BAHASA TARGET */}
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-800">
              1. 🌍 Pilih Bahasa yang Ingin Dipelajari
            </h3>
            <p className="text-xs text-slate-500">
              Mengubah bahasa akan otomatis menampilkan aksara (Thai / Hanzi / Latin), cara baca, dan suara pelafalan.
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {LANGUAGES.map((l) => {
                const active = l.code === language;
                return (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => setLanguage(l.code)}
                    className={`flex flex-col items-center justify-center rounded-2xl p-3.5 text-center transition ${
                      active
                        ? `bg-gradient-to-br ${l.gradient} text-white shadow-lg ring-4 ring-amber-300`
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    <span className="text-3xl">{l.flag}</span>
                    <span className="mt-1.5 text-xs font-extrabold">{l.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. PENGATURAN SUARA & CARA BACA */}
          <div className="rounded-2xl border-2 border-sky-100 bg-sky-50/60 p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-sky-900">
                  2. 🔊 Suara Pelafalan & Cara Membaca
                </h3>
                <p className="text-xs text-slate-600">
                  Atur kecepatan suara untuk mendengarkan nada Mandarin & intonasi Thailand dengan jelas.
                </p>
              </div>
              <button
                type="button"
                onClick={() => speak(sample.text, currentLang.bcp47, { rate: speechRate })}
                className="rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 px-3.5 py-2 text-xs font-extrabold text-white shadow hover:scale-105"
              >
                🔊 Tes Suara: {sample.text} ({sample.reading})
              </button>
            </div>

            {/* Kecepatan Suara */}
            <div>
              <p className="text-xs font-bold text-slate-700">Kecepatan Suara:</p>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {[
                  { rate: 0.6, label: "🐢 Lambat (0.6x)", desc: "Cocok belajar aksara baru" },
                  { rate: 0.8, label: "🚶 Santai (0.8x)", desc: "Jelas & mudah diikuti" },
                  { rate: 0.95, label: "🚀 Normal (1.0x)", desc: "Kecepatan percakapan" },
                ].map((opt) => {
                  const active = Math.abs(speechRate - opt.rate) < 0.05;
                  return (
                    <button
                      key={opt.rate}
                      type="button"
                      onClick={() => setSpeechRate(opt.rate)}
                      className={`rounded-xl p-2.5 text-left transition ${
                        active
                          ? "bg-sky-600 text-white shadow-md"
                          : "bg-white text-slate-700 hover:bg-sky-100"
                      }`}
                    >
                      <p className="text-xs font-extrabold">{opt.label}</p>
                      <p className={`text-[10px] ${active ? "text-sky-100" : "text-slate-500"}`}>
                        {opt.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Toggle Auto-speak & Tampilkan Cara Baca */}
            <div className="grid gap-2.5 sm:grid-cols-2">
              <label className="flex cursor-pointer items-center justify-between rounded-xl bg-white p-3 shadow-sm">
                <div>
                  <p className="text-xs font-extrabold text-slate-800">
                    🗣️ Otomatis Bunyikan Suara
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Putar suara saat kartu dibuka / dibalik
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={autoSpeak}
                  onChange={(e) => setAutoSpeak(e.target.checked)}
                  className="h-5 w-5 accent-pink-500"
                />
              </label>

              <label className="flex cursor-pointer items-center justify-between rounded-xl bg-white p-3 shadow-sm">
                <div>
                  <p className="text-xs font-extrabold text-slate-800">
                    📖 Tampilkan Cara Baca di Depan
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Pinyin / Romanisasi Thai / IPA di kartu depan
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={showReadingOnFront}
                  onChange={(e) => setShowReadingOnFront(e.target.checked)}
                  className="h-5 w-5 accent-pink-500"
                />
              </label>
            </div>
          </div>

          {/* 3. TEMA WARNA ANTI-NGANTUK */}
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-800">
              3. 🎨 Tema Warna Latar (Anti-Ngantuk)
            </h3>
            <p className="text-xs text-slate-500">
              Pilih suasana warna cerah agar mata tetap segar dan fokus saat menghafal:
            </p>
            <div className="mt-3 grid grid-cols-2 gap-3">
              {THEME_MOODS.map((m) => {
                const active = themeMood === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setThemeMood(m.id)}
                    className={`flex items-center gap-3 rounded-2xl border-2 p-3 text-left transition ${
                      active
                        ? "border-pink-500 bg-pink-50/70 shadow-md"
                        : "border-slate-200 bg-white hover:border-pink-300"
                    }`}
                  >
                    <div
                      className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br ${m.preview} text-2xl shadow-inner`}
                    >
                      {m.emoji}
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-900">{m.label}</p>
                      <p className="text-[11px] text-slate-600">{m.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex justify-end border-t border-slate-100 bg-slate-50 px-6 py-3.5">
          <button
            type="button"
            onClick={onClose}
            className="rounded-2xl bg-gradient-to-r from-pink-500 to-orange-500 px-6 py-2.5 text-sm font-extrabold text-white shadow-md hover:scale-105"
          >
            ✓ Simpan & Lanjut Belajar
          </button>
        </div>
      </div>
    </div>
  );
}
