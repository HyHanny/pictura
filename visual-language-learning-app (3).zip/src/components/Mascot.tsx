"use client";

type Props = {
  message: string;
  emotion?: "happy" | "excited" | "thinking" | "celebrate";
};

const EMOTION_MAP: Record<string, { eyes: string; mouth: string; bg: string; bounce: string }> = {
  happy: { eyes: "• •", mouth: "ᴗ", bg: "from-sky-300 to-blue-500", bounce: "" },
  excited: { eyes: "★ ★", mouth: "▽", bg: "from-amber-300 to-orange-500", bounce: "animate-wiggle" },
  thinking: { eyes: "• –", mouth: "〰", bg: "from-violet-300 to-purple-500", bounce: "" },
  celebrate: { eyes: "^ ^", mouth: "▽", bg: "from-pink-300 to-rose-500", bounce: "animate-float" },
};

export default function Mascot({ message, emotion = "happy" }: Props) {
  const e = EMOTION_MAP[emotion];
  return (
    <div className="flex items-end gap-3">
      <div className={`relative grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br ${e.bg} text-white shadow-lg ${e.bounce}`}>
        <span className="absolute inset-0 rounded-full bg-white/20" />
        <div className="relative z-10 flex flex-col items-center justify-center text-[10px] font-bold leading-none">
          <span className="tracking-widest">{e.eyes}</span>
          <span className="-mt-0.5 text-base">{e.mouth}</span>
        </div>
        <span className="absolute -right-1 -top-1 text-lg">📚</span>
      </div>
      <div className="relative max-w-[260px] rounded-2xl rounded-bl-sm bg-white px-4 py-3 text-sm font-medium text-slate-700 shadow-lg">
        {message}
        <div className="absolute -left-2 bottom-2 h-4 w-4 rotate-45 bg-white" />
      </div>
    </div>
  );
}
