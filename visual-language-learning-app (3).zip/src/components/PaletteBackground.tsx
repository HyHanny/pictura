"use client";

import { useLearn, type ThemeMood } from "@/lib/LearnContext";

const MOOD_STYLES: Record<
  ThemeMood,
  {
    base: string;
    blob1: string;
    blob2: string;
    blob3: string;
    blob4: string;
  }
> = {
  rainbow: {
    base: "from-pink-100 via-amber-50 to-sky-100",
    blob1: "bg-pink-300/45",
    blob2: "bg-amber-300/45",
    blob3: "bg-sky-300/45",
    blob4: "bg-emerald-200/45",
  },
  tropical: {
    base: "from-yellow-100 via-orange-50 to-rose-100",
    blob1: "bg-amber-300/50",
    blob2: "bg-orange-400/40",
    blob3: "bg-rose-300/45",
    blob4: "bg-lime-300/40",
  },
  mintberry: {
    base: "from-emerald-100 via-teal-50 to-fuchsia-100",
    blob1: "bg-emerald-300/45",
    blob2: "bg-teal-300/45",
    blob3: "bg-fuchsia-300/45",
    blob4: "bg-violet-300/40",
  },
  skycandy: {
    base: "from-cyan-100 via-indigo-50 to-pink-100",
    blob1: "bg-cyan-300/45",
    blob2: "bg-indigo-300/45",
    blob3: "bg-pink-300/45",
    blob4: "bg-amber-200/45",
  },
};

export default function PaletteBackground() {
  const { themeMood } = useLearn();
  const s = MOOD_STYLES[themeMood] ?? MOOD_STYLES.rainbow;

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden transition-colors duration-700">
      <div className={`absolute inset-0 bg-gradient-to-br ${s.base}`} />
      <div
        className={`absolute -top-32 -left-32 h-96 w-96 rounded-full ${s.blob1} blur-3xl animate-float`}
      />
      <div
        className={`absolute top-1/3 -right-32 h-[28rem] w-[28rem] rounded-full ${s.blob2} blur-3xl animate-float`}
        style={{ animationDelay: "1s" }}
      />
      <div
        className={`absolute -bottom-32 left-1/4 h-[26rem] w-[26rem] rounded-full ${s.blob3} blur-3xl animate-float`}
        style={{ animationDelay: "2s" }}
      />
      <div
        className={`absolute bottom-1/4 right-1/3 h-80 w-80 rounded-full ${s.blob4} blur-3xl animate-float`}
        style={{ animationDelay: "3s" }}
      />
    </div>
  );
}
