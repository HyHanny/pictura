"use client";

type Props = {
  label: string;
  emoji: string;
  gradient: string;
  tagline: string;
  count: number;
  onClick: () => void;
  delay?: number;
};

export default function CategoryTile({
  label,
  emoji,
  gradient,
  tagline,
  count,
  onClick,
  delay = 0,
}: Props) {
  return (
    <button
      onClick={onClick}
      style={{ animationDelay: `${delay}ms` }}
      className={`group relative overflow-hidden rounded-[28px] bg-gradient-to-br ${gradient} p-6 text-left text-white shadow-[0_18px_35px_-10px_rgba(0,0,0,0.25)] transition-all duration-300 hover:-translate-y-1 hover:rotate-[-1deg] hover:shadow-[0_25px_45px_-10px_rgba(0,0,0,0.35)] animate-pop`}
    >
      <div className="absolute -top-8 -right-8 h-28 w-28 rounded-full bg-white/30 blur-2xl transition-all duration-500 group-hover:scale-125" />
      <div className="absolute -bottom-8 -left-8 h-24 w-24 rounded-full bg-black/10 blur-xl" />

      <div className="relative z-10 flex flex-col gap-2">
        <span className="text-5xl drop-shadow-lg transition group-hover:animate-wiggle">
          {emoji}
        </span>
        <h3 className="text-2xl font-bold drop-shadow-md">{label}</h3>
        <p className="text-sm font-medium opacity-90">{tagline}</p>
        <span className="mt-2 inline-block w-fit rounded-full bg-white/30 px-3 py-1 text-xs font-semibold backdrop-blur-sm">
          {count} kata
        </span>
      </div>
    </button>
  );
}
