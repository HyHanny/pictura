"use client";

import { useXp } from "@/lib/useXp";

type Props = {
  onOpenBadges?: () => void;
};

export default function XpHeader({ onOpenBadges }: Props) {
  const { xp, levelInfo, badges, loaded } = useXp();

  if (!loaded) {
    return (
      <div className="glass rounded-2xl p-3 shadow-md flex items-center gap-3">
        <div className="h-12 w-12 animate-pulse rounded-full bg-slate-200" />
        <div className="flex-1 space-y-2">
          <div className="h-3 w-24 animate-pulse rounded-full bg-slate-200" />
          <div className="h-2 w-full animate-pulse rounded-full bg-slate-200" />
        </div>
      </div>
    );
  }

  const pct = Math.min(100, Math.round((levelInfo.xpInLevel / levelInfo.xpForNext) * 100));

  return (
    <div className="glass space-y-3 rounded-2xl p-3 shadow-md">
      <div className="flex items-center gap-3">
        <div className="relative grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-amber-300 via-orange-400 to-pink-500 text-2xl font-black text-white shadow-lg">
          {xp.level}
          <span className="absolute -bottom-1 rounded-full bg-white px-2 py-0.5 text-[9px] font-bold text-orange-600 shadow">
            LV
          </span>
        </div>
        <div className="flex-1">
          <div className="flex items-baseline justify-between gap-2">
            <p className="text-sm font-bold text-slate-800">Level {xp.level}</p>
            <p className="text-xs font-semibold text-slate-600">
              {levelInfo.xpInLevel}/{levelInfo.xpForNext} XP
            </p>
          </div>
          <div className="mt-1 h-2.5 overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-400 via-pink-500 to-fuchsia-500 transition-all duration-700"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-gradient-to-br from-amber-100 to-orange-100 px-2 py-2">
          <p className="text-lg font-black text-orange-600">{xp.totalXp}</p>
          <p className="text-[10px] font-bold uppercase tracking-wider text-orange-700">Total XP</p>
        </div>
        <div className="rounded-xl bg-gradient-to-br from-rose-100 to-pink-100 px-2 py-2">
          <p className="text-lg font-black text-rose-600">
            🔥 {xp.streak}
          </p>
          <p className="text-[10px] font-bold uppercase tracking-wider text-rose-700">Streak</p>
        </div>
        <button
          onClick={onOpenBadges}
          className="rounded-xl bg-gradient-to-br from-violet-100 to-purple-100 px-2 py-2 transition hover:scale-105"
        >
          <p className="text-lg font-black text-violet-600">🏅 {badges.length}</p>
          <p className="text-[10px] font-bold uppercase tracking-wider text-violet-700">Badge</p>
        </button>
      </div>
    </div>
  );
}
