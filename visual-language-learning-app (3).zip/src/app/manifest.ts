import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Pictura · Belajar Bahasa dengan Gambar",
    short_name: "Pictura",
    description:
      "Aplikasi belajar bahasa Inggris, Thailand, Mandarin, dan Indonesia dengan gambar, warna ceria, cara baca, dan latihan menulis.",
    start_url: "/",
    display: "standalone",
    background_color: "#fdf2f8",
    theme_color: "#ec4899",
    icons: [
      {
        src: "/favicon.ico",
        sizes: "any",
        type: "image/x-icon",
      },
    ],
  };
}
