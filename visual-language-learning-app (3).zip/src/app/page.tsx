import { db } from "@/db";
import { cards } from "@/db/schema";
import { seedDatabaseIfEmpty, CATEGORY_INFO } from "@/lib/cards";
import HomeClient from "@/components/HomeClient";

export const dynamic = "force-dynamic";

type DbCardRow = {
  id: number;
  indonesian: string;
  english: string;
  pronunciation: string;
  category: keyof typeof CATEGORY_INFO;
  emoji: string;
  gradient: string;
  exampleId: string | null;
  exampleEn: string | null;
  thai: string | null;
  thaiReading: string | null;
  thaiExample: string | null;
  thaiExampleReading: string | null;
  chinese: string | null;
  chineseReading: string | null;
  chineseExample: string | null;
  chineseExampleReading: string | null;
};

export default async function HomePage() {
  await seedDatabaseIfEmpty();

  const cardRows = (await db.select().from(cards).orderBy(cards.id)) as DbCardRow[];

  // Aggregate by category for the home tiles
  const categoryCounts = new Map<string, number>();
  for (const c of cardRows) {
    categoryCounts.set(c.category, (categoryCounts.get(c.category) ?? 0) + 1);
  }

  // Server-rendered placeholder favorites/stats — the client component hydrates them from the API.
  const favoriteCardIds: number[] = [];

  const categories = (Object.keys(CATEGORY_INFO) as (keyof typeof CATEGORY_INFO)[]).map(
    (key) => ({
      key,
      info: CATEGORY_INFO[key],
      count: categoryCounts.get(key) ?? 0,
    }),
  );

  return (
    <HomeClient
      cards={cardRows.map((c) => ({
        id: c.id,
        indonesian: c.indonesian,
        english: c.english,
        pronunciation: c.pronunciation,
        category: c.category,
        emoji: c.emoji,
        gradient: c.gradient,
        exampleId: c.exampleId,
        exampleEn: c.exampleEn,
        thai: c.thai,
        thaiReading: c.thaiReading,
        thaiExample: c.thaiExample,
        thaiExampleReading: c.thaiExampleReading,
        chinese: c.chinese,
        chineseReading: c.chineseReading,
        chineseExample: c.chineseExample,
        chineseExampleReading: c.chineseExampleReading,
      }))}
      categories={categories}
      initialFavoriteIds={favoriteCardIds}
      initialStats={{}}
    />
  );
}
