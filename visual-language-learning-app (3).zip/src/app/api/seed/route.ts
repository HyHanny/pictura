import { NextResponse } from "next/server";
import { seedDatabaseIfEmpty } from "@/lib/cards";

export async function POST() {
  try {
    await seedDatabaseIfEmpty();
    return NextResponse.json({ ok: true, message: "Database seeded." });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}
