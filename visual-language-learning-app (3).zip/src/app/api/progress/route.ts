import { NextResponse } from "next/server";
import { NextRequest } from "next/server";
import { db } from "@/db";
import { progress } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
  }
  try {
    const rows = await db
      .select({
        cardId: progress.cardId,
        rememberedCount: sql<number>`sum(case when ${progress.remembered} then 1 else 0 end)`,
        forgottenCount: sql<number>`sum(case when ${progress.remembered} then 0 else 1 end)`,
      })
      .from(progress)
      .where(eq(progress.sessionId, sessionId))
      .groupBy(progress.cardId);
    const reviewRows = await db
      .select()
      .from(progress)
      .where(eq(progress.sessionId, sessionId));
    return NextResponse.json({ ok: true, stats: rows, history: reviewRows });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { sessionId, cardId, remembered } = body as {
      sessionId: string;
      cardId: number;
      remembered: boolean;
    };
    if (!sessionId || !cardId) {
      return NextResponse.json({ ok: false, error: "missing fields" }, { status: 400 });
    }
    await db.insert(progress).values({ sessionId, cardId, remembered });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}
