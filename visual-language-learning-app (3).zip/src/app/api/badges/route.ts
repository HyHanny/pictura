import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { unlockedBadges, progress, cards } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { BADGES } from "@/lib/gamification";

/**
 * Manually unlock the "category_master" badge once a user remembers every
 * word in at least one category.
 */
export async function POST(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
  }
  try {
    // Find which categories are fully remembered
    const rows = await db
      .select({
        category: cards.category,
        total: sql<number>`count(distinct ${cards.id})`,
        remembered: sql<number>`count(distinct case when ${progress.remembered} then ${cards.id} end)`,
      })
      .from(cards)
      .leftJoin(progress, and(eq(progress.cardId, cards.id), eq(progress.sessionId, sessionId)))
      .groupBy(cards.category)
      .having(sql`count(distinct ${cards.id}) = count(distinct case when ${progress.remembered} then ${cards.id} end)`);

    const unlockedSet = new Set(
      (
        await db
          .select({ code: unlockedBadges.code })
          .from(unlockedBadges)
          .where(eq(unlockedBadges.sessionId, sessionId))
      ).map((r) => r.code),
    );

    const newlyUnlocked: string[] = [];
    for (const r of rows) {
      if (r.total > 0 && r.remembered === r.total && !unlockedSet.has("category_master")) {
        newlyUnlocked.push("category_master");
      }
    }

    if (newlyUnlocked.length > 0) {
      await db
        .insert(unlockedBadges)
        .values(newlyUnlocked.map((code) => ({ sessionId, code })));
    }

    const codes = (
      await db
        .select({ code: unlockedBadges.code })
        .from(unlockedBadges)
        .where(eq(unlockedBadges.sessionId, sessionId))
    ).map((r) => r.code);

    return NextResponse.json({
      ok: true,
      unlocked: codes,
      newlyUnlocked,
      all: BADGES.map((b) => ({ ...b, unlocked: codes.includes(b.code) })),
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
  }
  try {
    const codes = (
      await db
        .select({ code: unlockedBadges.code })
        .from(unlockedBadges)
        .where(eq(unlockedBadges.sessionId, sessionId))
    ).map((r) => r.code);
    return NextResponse.json({
      ok: true,
      unlocked: codes,
      all: BADGES.map((b) => ({ ...b, unlocked: codes.includes(b.code) })),
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
