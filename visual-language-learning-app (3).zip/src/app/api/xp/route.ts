import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { xp, unlockedBadges, progress } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import {
  BADGES,
  XP,
  levelFromXp,
  todayKey,
  yesterdayKey,
} from "@/lib/gamification";

async function loadXpRow(sessionId: string) {
  const rows = await db.select().from(xp).where(eq(xp.sessionId, sessionId)).limit(1);
  if (rows.length > 0) return rows[0];
  const inserted = await db
    .insert(xp)
    .values({ sessionId })
    .returning();
  return inserted[0];
}

async function unlockedCodes(sessionId: string): Promise<string[]> {
  const rows = await db
    .select({ code: unlockedBadges.code })
    .from(unlockedBadges)
    .where(eq(unlockedBadges.sessionId, sessionId));
  return rows.map((r) => r.code);
}

type BadgeCheckContext = {
  totalRemembered: number; // unique cards remembered at least once
  streak: number;
  cardRememberedNow: boolean;
  perfectQuizInARow?: number; // passed via body
  totalQuizCorrect?: number;
};

function evaluateBadgeUnlocks(
  before: Set<string>,
  ctx: BadgeCheckContext,
): string[] {
  const newOnes: string[] = [];
  for (const b of BADGES) {
    if (before.has(b.code)) continue;
    let unlock = false;
    switch (b.code) {
      case "first_word":
        unlock = ctx.totalRemembered >= 1;
        break;
      case "ten_words":
        unlock = ctx.totalRemembered >= 10;
        break;
      case "fifty_words":
        unlock = ctx.totalRemembered >= 50;
        break;
      case "perfect_quiz":
        unlock = (ctx.perfectQuizInARow ?? 0) >= 5;
        break;
      case "streak_3":
        unlock = ctx.streak >= 3;
        break;
      case "streak_7":
        unlock = ctx.streak >= 7;
        break;
      case "quiz_champ":
        unlock = (ctx.totalQuizCorrect ?? 0) >= 50;
        break;
      case "category_master":
        // Not evaluated here (we don't have category context); unlock via /api/xp unlock
        break;
    }
    if (unlock) newOnes.push(b.code);
  }
  return newOnes;
}

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
  }
  try {
    const row = await loadXpRow(sessionId);
    const codes = await unlockedCodes(sessionId);
    return NextResponse.json({
      ok: true,
      xp: {
        totalXp: row.totalXp,
        level: row.level,
        streak: row.streak,
        longestStreak: row.longestStreak,
        lastSeenDate: row.lastSeenDate,
      },
      badges: codes,
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}

type PostBody = {
  /** XP delta to add (positive for earn, negative to undo) */
  delta?: number;
  /** Source of the XP: 'flashcard' | 'quiz' | 'streak' | 'manual' */
  source?: "flashcard" | "quiz" | "streak" | "manual";
  /** For flashcard: was the answer correct? */
  correct?: boolean;
  /** When a quiz finishes with perfect score */
  perfectQuizSize?: number;
  /** When a quiz question is answered correctly */
  quizCorrectCount?: number;
};

export async function POST(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
  }
  try {
    const body = (await req.json().catch(() => ({}))) as PostBody;
    const beforeRow = await loadXpRow(sessionId);
    let totalXp = beforeRow.totalXp;
    let streak = beforeRow.streak;
    let longestStreak = beforeRow.longestStreak;
    const lastSeen = beforeRow.lastSeenDate ?? null;
    const today = todayKey();
    const yest = yesterdayKey();

    // Streak update — only when this call represents user activity.
    if (body.source && body.source !== "manual") {
      if (lastSeen !== today) {
        if (lastSeen === yest) {
          streak = streak + 1;
        } else if (lastSeen === null) {
          streak = 1;
        } else {
          streak = 1;
        }
        if (streak > longestStreak) longestStreak = streak;
        // Daily activity bonus once per day.
        totalXp += XP.streakBonus;
      }
    }

    let delta = body.delta ?? 0;
    if (body.source === "flashcard" && body.correct) delta += XP.correctFlashcard;
    if (body.source === "flashcard" && body.correct) delta += XP.perfectCard; // bonus
    if (body.source === "quiz" && body.correct) delta += XP.correctQuiz;
    totalXp = Math.max(0, totalXp + delta);

    const { level } = levelFromXp(totalXp);

    await db
      .update(xp)
      .set({
        totalXp,
        level,
        streak,
        longestStreak,
        lastSeenDate: today,
        updatedAt: new Date(),
      })
      .where(eq(xp.sessionId, sessionId));

    // Stats for badge evaluation
    const uniqueRememberedRows = await db
      .select({ cardId: progress.cardId })
      .from(progress)
      .where(and(eq(progress.sessionId, sessionId), eq(progress.remembered, true)));
    const uniqueRememberedSet = new Set(uniqueRememberedRows.map((r) => r.cardId));

    const beforeBadges = new Set(await unlockedCodes(sessionId));
    const newBadges = evaluateBadgeUnlocks(beforeBadges, {
      totalRemembered: uniqueRememberedSet.size,
      streak,
      cardRememberedNow: !!body.correct,
      perfectQuizInARow: body.perfectQuizSize,
      totalQuizCorrect: body.quizCorrectCount,
    });
    if (newBadges.length > 0) {
      await db
        .insert(unlockedBadges)
        .values(newBadges.map((code) => ({ sessionId, code })));
    }

    return NextResponse.json({
      ok: true,
      xp: { totalXp, level, streak, longestStreak, lastSeenDate: today },
      newBadges,
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
