import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cards } from "@/db/schema";
import { seedDatabaseIfEmpty, type CardCategory } from "@/lib/cards";

export async function GET() {
  try {
    await seedDatabaseIfEmpty();
    const all = await db.select().from(cards).orderBy(cards.id);
    return NextResponse.json({ ok: true, cards: all });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      indonesian,
      english,
      pronunciation,
      category,
      emoji,
      gradient,
      exampleId,
      exampleEn,
      thai,
      thaiReading,
      thaiExample,
      thaiExampleReading,
      chinese,
      chineseReading,
      chineseExample,
      chineseExampleReading,
    } = body as {
      indonesian: string;
      english: string;
      pronunciation?: string;
      category: CardCategory;
      emoji: string;
      gradient?: string;
      exampleId?: string;
      exampleEn?: string;
      thai?: string;
      thaiReading?: string;
      thaiExample?: string;
      thaiExampleReading?: string;
      chinese?: string;
      chineseReading?: string;
      chineseExample?: string;
      chineseExampleReading?: string;
    };

    if (!indonesian?.trim() || !english?.trim() || !emoji?.trim()) {
      return NextResponse.json(
        { ok: false, error: "Kata Indonesia, Inggris, dan Emoji wajib diisi." },
        { status: 400 },
      );
    }

    const inserted = await db
      .insert(cards)
      .values({
        indonesian: indonesian.trim(),
        english: english.trim(),
        pronunciation: pronunciation?.trim() || `/${english.trim().toLowerCase()}/`,
        category: category || "benda",
        emoji: emoji.trim(),
        gradient: gradient || "from-pink-400 via-rose-400 to-orange-400",
        exampleId: exampleId?.trim() || null,
        exampleEn: exampleEn?.trim() || null,
        thai: thai?.trim() || null,
        thaiReading: thaiReading?.trim() || null,
        thaiExample: thaiExample?.trim() || null,
        thaiExampleReading: thaiExampleReading?.trim() || null,
        chinese: chinese?.trim() || null,
        chineseReading: chineseReading?.trim() || null,
        chineseExample: chineseExample?.trim() || null,
        chineseExampleReading: chineseExampleReading?.trim() || null,
      })
      .returning();

    return NextResponse.json({ ok: true, card: inserted[0] });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}
