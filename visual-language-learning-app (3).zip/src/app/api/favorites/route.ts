import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { favorites } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
  }
  try {
    const rows = await db.select().from(favorites).where(eq(favorites.sessionId, sessionId));
    return NextResponse.json({ ok: true, favorites: rows.map((r) => r.cardId) });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const sessionId = req.nextUrl.searchParams.get("sessionId");
    if (!sessionId) {
      return NextResponse.json({ ok: false, error: "sessionId required" }, { status: 400 });
    }
    const body = (await req.json()) as { cardId: number; favorite: boolean };
    if (!body.cardId) {
      return NextResponse.json({ ok: false, error: "cardId required" }, { status: 400 });
    }
    if (body.favorite) {
      const existing = await db
        .select()
        .from(favorites)
        .where(and(eq(favorites.sessionId, sessionId), eq(favorites.cardId, body.cardId)));
      if (existing.length === 0) {
        await db.insert(favorites).values({ sessionId, cardId: body.cardId });
      }
    } else {
      await db
        .delete(favorites)
        .where(and(eq(favorites.sessionId, sessionId), eq(favorites.cardId, body.cardId)));
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}
