export type CardCategory =
  | "hewan"
  | "buah"
  | "warna"
  | "angka"
  | "makanan"
  | "benda"
  | "tubuh"
  | "alam"
  | "keluarga"
  | "aktivitas"
  | "tempat"
  | "transportasi"
  | "pakaian"
  | "emosi"
  | "waktu"
  | "profesi";

export const CATEGORY_INFO: Record<
  CardCategory,
  { label: string; emoji: string; gradient: string; tagline: string }
> = {
  hewan: {
    label: "Hewan",
    emoji: "🐾",
    gradient: "from-orange-300 to-rose-400",
    tagline: "15 satwa lucu & liar",
  },
  buah: {
    label: "Buah & Sayur",
    emoji: "🍇",
    gradient: "from-rose-300 to-fuchsia-400",
    tagline: "15 buah & sayur segar",
  },
  warna: {
    label: "Warna & Bentuk",
    emoji: "🎨",
    gradient: "from-yellow-300 to-pink-400",
    tagline: "15 warna pelangi & bentuk",
  },
  angka: {
    label: "Angka",
    emoji: "🔢",
    gradient: "from-cyan-300 to-blue-500",
    tagline: "15 angka & hitungan",
  },
  makanan: {
    label: "Makanan",
    emoji: "🍕",
    gradient: "from-amber-300 to-orange-500",
    tagline: "15 kuliner & minuman",
  },
  benda: {
    label: "Benda & Rumah",
    emoji: "📦",
    gradient: "from-indigo-300 to-violet-500",
    tagline: "15 benda sehari-hari",
  },
  tubuh: {
    label: "Tubuh",
    emoji: "🫀",
    gradient: "from-pink-300 to-rose-500",
    tagline: "15 anggota tubuh",
  },
  alam: {
    label: "Alam & Cuaca",
    emoji: "🌈",
    gradient: "from-emerald-300 to-cyan-500",
    tagline: "15 keindahan bumi & langit",
  },
  keluarga: {
    label: "Keluarga",
    emoji: "👨‍👩‍👧‍👦",
    gradient: "from-pink-400 to-purple-500",
    tagline: "15 panggilan keluarga & teman",
  },
  aktivitas: {
    label: "Kata Kerja",
    emoji: "🏃",
    gradient: "from-orange-400 to-pink-500",
    tagline: "15 aktivitas harian",
  },
  tempat: {
    label: "Tempat & Kota",
    emoji: "🏫",
    gradient: "from-sky-400 to-indigo-500",
    tagline: "15 lokasi & bangunan",
  },
  transportasi: {
    label: "Transportasi",
    emoji: "🚀",
    gradient: "from-teal-400 to-blue-500",
    tagline: "15 kendaraan & perjalanan",
  },
  pakaian: {
    label: "Pakaian",
    emoji: "👗",
    gradient: "from-fuchsia-400 to-rose-500",
    tagline: "15 busana & aksesoris",
  },
  emosi: {
    label: "Perasaan & Sifat",
    emoji: "😊",
    gradient: "from-amber-400 to-red-500",
    tagline: "15 ekspresi & kata sifat",
  },
  waktu: {
    label: "Waktu & Sapaan",
    emoji: "👋",
    gradient: "from-violet-400 to-fuchsia-500",
    tagline: "15 salam & keterangan waktu",
  },
  profesi: {
    label: "Profesi & Sekolah",
    emoji: "👩‍🏫",
    gradient: "from-emerald-400 to-teal-600",
    tagline: "15 pekerjaan & dunia belajar",
  },
};
