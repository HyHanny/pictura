export type LanguageCode = "id" | "en" | "th" | "zh";

export type LanguageDef = {
  code: LanguageCode;
  /** Short label for chips */
  shortLabel: string;
  /** Long label */
  label: string;
  /** Emoji flag/character */
  flag: string;
  /** BCP-47 tag for Web Speech */
  bcp47: string;
  /** Column name on CardRow, e.g. "english" */
  textField: string;
  /** Optional reading/romanization field, e.g. "pronunciation" or "thaiReading" */
  readingField?: string;
  /** Example field name in source language */
  exampleField?: string;
  /** Example reading field name */
  exampleReadingField?: string;
  /** Source language for the example pair (Indonesian source) */
  exampleSourceField?: string;
  /** Tailwind gradient for chip background */
  gradient: string;
};

export const LANGUAGES: LanguageDef[] = [
  {
    code: "id",
    shortLabel: "ID",
    label: "Bahasa Indonesia",
    flag: "🇮🇩",
    bcp47: "id-ID",
    textField: "indonesian",
    exampleField: "exampleId",
    exampleReadingField: undefined,
    exampleSourceField: "indonesian",
    gradient: "from-red-400 via-white to-red-400",
  },
  {
    code: "en",
    shortLabel: "EN",
    label: "English",
    flag: "🇬🇧",
    bcp47: "en-US",
    textField: "english",
    readingField: "pronunciation",
    exampleField: "exampleEn",
    exampleSourceField: "indonesian",
    gradient: "from-blue-400 via-indigo-400 to-violet-500",
  },
  {
    code: "th",
    shortLabel: "TH",
    label: "ภาษาไทย (Thai)",
    flag: "🇹🇭",
    bcp47: "th-TH",
    textField: "thai",
    readingField: "thaiReading",
    exampleField: "thaiExample",
    exampleReadingField: "thaiExampleReading",
    exampleSourceField: "indonesian",
    gradient: "from-purple-500 via-fuchsia-400 to-pink-400",
  },
  {
    code: "zh",
    shortLabel: "ZH",
    label: "中文 (Chinese)",
    flag: "🇨🇳",
    bcp47: "zh-CN",
    textField: "chinese",
    readingField: "chineseReading",
    exampleField: "chineseExample",
    exampleReadingField: "chineseExampleReading",
    exampleSourceField: "indonesian",
    gradient: "from-red-500 via-amber-400 to-yellow-400",
  },
];

export const LANGUAGE_BY_CODE: Record<LanguageCode, LanguageDef> = Object.fromEntries(
  LANGUAGES.map((l) => [l.code, l]),
) as Record<LanguageCode, LanguageDef>;

export const DEFAULT_LANG: LanguageCode = "en";

/** Storage key for user-chosen language */
const STORAGE_KEY = "pictura.lang";

export function getStoredLanguage(): LanguageCode {
  if (typeof window === "undefined") return DEFAULT_LANG;
  const v = window.localStorage.getItem(STORAGE_KEY);
  if (v === "id" || v === "en" || v === "th" || v === "zh") return v;
  return DEFAULT_LANG;
}

export function setStoredLanguage(code: LanguageCode) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, code);
}

/** Pick the best voice for a given BCP-47 tag (browser dependent). */
export function pickVoice(bcp47: string): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  if (voices.length === 0) return null;
  // Exact match first
  return (
    voices.find((v) => v.lang === bcp47) ??
    voices.find((v) => v.lang.toLowerCase().startsWith(bcp47.split("-")[0].toLowerCase())) ??
    voices.find((v) =>
      v.lang.toLowerCase().includes(bcp47.split("-")[0].toLowerCase()),
    ) ??
    null
  );
}
