export type BadgeDef = {
  code: string;
  emoji: string;
  title: string;
  description: string;
  /** Tailwind gradient classes for the badge card background */
  gradient: string;
};

export const BADGES: BadgeDef[] = [
  {
    code: "first_word",
    emoji: "🌱",
    title: "Pemula",
    description: "Hafal kata pertamamu",
    gradient: "from-emerald-300 to-green-500",
  },
  {
    code: "ten_words",
    emoji: "📚",
    title: "Rajin Belajar",
    description: "Hafal 10 kata berbeda",
    gradient: "from-sky-300 to-blue-500",
  },
  {
    code: "perfect_quiz",
    emoji: "🎯",
    title: "Sempurna!",
    description: "Selesaikan kuis tanpa salah",
    gradient: "from-pink-300 to-rose-500",
  },
  {
    code: "streak_3",
    emoji: "🔥",
    title: "Streak 3 Hari",
    description: "Belajar 3 hari berturut-turut",
    gradient: "from-orange-300 to-red-500",
  },
  {
    code: "streak_7",
    emoji: "⚡",
    title: "Streak Seminggu",
    description: "Belajar 7 hari berturut-turut",
    gradient: "from-amber-300 to-orange-500",
  },
  {
    code: "fifty_words",
    emoji: "🚀",
    title: "Kosakata 50",
    description: "Hafal 50 kata berbeda",
    gradient: "from-violet-300 to-purple-600",
  },
  {
    code: "category_master",
    emoji: "👑",
    title: "Master Kategori",
    description: "Hafal semua kata di 1 kategori",
    gradient: "from-fuchsia-300 to-pink-600",
  },
  {
    code: "quiz_champ",
    emoji: "🏆",
    title: "Juara Kuis",
    description: "Dapatkan 50 jawaban benar di kuis",
    gradient: "from-yellow-300 to-amber-500",
  },
];

export const BADGE_BY_CODE: Record<string, BadgeDef> = Object.fromEntries(
  BADGES.map((b) => [b.code, b]),
);

/** XP rules */
export const XP = {
  correctFlashcard: 10,
  perfectCard: 5, // bonus if had not remembered before
  correctQuiz: 15,
  streakBonus: 5, // per day active
} as const;

/** Level curve: xp needed = 50 * level^1.5 */
export function xpForLevel(level: number): number {
  return Math.round(50 * Math.pow(level, 1.5));
}

export function levelFromXp(totalXp: number): { level: number; xpInLevel: number; xpForNext: number } {
  let level = 1;
  let remaining = totalXp;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level += 1;
  }
  return {
    level,
    xpInLevel: remaining,
    xpForNext: xpForLevel(level),
  };
}

export type LevelInfo = ReturnType<typeof levelFromXp>;

/** Date helpers (yyyy-mm-dd in local time) */
export function todayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function yesterdayKey(d = new Date()): string {
  const y = new Date(d);
  y.setDate(y.getDate() - 1);
  return todayKey(y);
}
