"use client";

import { useCallback } from "react";

export type SpeakOptions = {
  rate?: number;
  pitch?: number;
  volume?: number;
};

export function speak(text: string, lang: string = "en-US", opts: SpeakOptions = {}) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  if (!text) return;
  try {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = lang;
    utter.rate = opts.rate ?? 0.9;
    utter.pitch = opts.pitch ?? 1;
    utter.volume = opts.volume ?? 1;

    // Try to pick a natural-sounding voice if available
    const voices = window.speechSynthesis.getVoices();
    if (voices.length) {
      const preferred = voices.find((v) => v.lang === lang) ?? voices.find((v) => v.lang.startsWith(lang.split("-")[0]));
      if (preferred) utter.voice = preferred;
    }
    window.speechSynthesis.speak(utter);
  } catch {
    /* ignore */
  }
}

export function stopSpeaking() {
  if (typeof window === "undefined") return;
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}

export function useSpeak() {
  return useCallback((text: string, lang: string = "en-US", opts?: SpeakOptions) => {
    speak(text, lang, opts);
  }, []);
}
