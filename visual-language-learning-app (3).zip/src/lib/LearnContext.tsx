"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  LANGUAGES,
  getStoredLanguage,
  setStoredLanguage,
  type LanguageCode,
} from "@/lib/languages";

export type ThemeMood = "rainbow" | "tropical" | "mintberry" | "skycandy";

export const THEME_MOODS: {
  id: ThemeMood;
  label: string;
  emoji: string;
  desc: string;
  preview: string;
}[] = [
  {
    id: "rainbow",
    label: "Pelangi Ceria",
    emoji: "🌈",
    desc: "Kombinasi pink, amber, dan biru langit yang segar",
    preview: "from-pink-300 via-amber-200 to-sky-300",
  },
  {
    id: "tropical",
    label: "Tropis Semangat",
    emoji: "☀️",
    desc: "Warna hangat matahari & jeruk anti-ngantuk",
    preview: "from-yellow-300 via-orange-300 to-rose-300",
  },
  {
    id: "mintberry",
    label: "Mint & Berry",
    emoji: "🍬",
    desc: "Segar di mata dengan hijau mint & ungu berry",
    preview: "from-emerald-200 via-teal-200 to-fuchsia-300",
  },
  {
    id: "skycandy",
    label: "Awan Permen",
    emoji: "🦄",
    desc: "Biru elektrik, ungu pastel, dan magenta ceria",
    preview: "from-cyan-200 via-indigo-200 to-pink-300",
  },
];

const SETTINGS_KEY = "pictura.settings.v1";

type StoredSettings = {
  speechRate: number;
  autoSpeak: boolean;
  showReadingOnFront: boolean;
  themeMood: ThemeMood;
};

const DEFAULT_SETTINGS: StoredSettings = {
  speechRate: 0.9,
  autoSpeak: true,
  showReadingOnFront: true,
  themeMood: "rainbow",
};

type LearnContextValue = {
  language: LanguageCode;
  setLanguage: (code: LanguageCode) => void;
  available: typeof LANGUAGES;
  ready: boolean;
  speechRate: number;
  setSpeechRate: (rate: number) => void;
  autoSpeak: boolean;
  setAutoSpeak: (val: boolean) => void;
  showReadingOnFront: boolean;
  setShowReadingOnFront: (val: boolean) => void;
  themeMood: ThemeMood;
  setThemeMood: (mood: ThemeMood) => void;
};

const LearnContext = createContext<LearnContextValue | null>(null);

export function LearnProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<LanguageCode>("en");
  const [settings, setSettings] = useState<StoredSettings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setLanguageState(getStoredLanguage());
    try {
      const raw = window.localStorage.getItem(SETTINGS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<StoredSettings>;
        setSettings((prev) => ({ ...prev, ...parsed }));
      }
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  const persistSettings = useCallback((next: Partial<StoredSettings>) => {
    setSettings((prev) => {
      const merged = { ...prev, ...next };
      try {
        window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(merged));
      } catch {
        /* ignore */
      }
      return merged;
    });
  }, []);

  const setLanguage = useCallback((code: LanguageCode) => {
    setLanguageState(code);
    setStoredLanguage(code);
  }, []);

  const setSpeechRate = useCallback(
    (speechRate: number) => persistSettings({ speechRate }),
    [persistSettings],
  );

  const setAutoSpeak = useCallback(
    (autoSpeak: boolean) => persistSettings({ autoSpeak }),
    [persistSettings],
  );

  const setShowReadingOnFront = useCallback(
    (showReadingOnFront: boolean) => persistSettings({ showReadingOnFront }),
    [persistSettings],
  );

  const setThemeMood = useCallback(
    (themeMood: ThemeMood) => persistSettings({ themeMood }),
    [persistSettings],
  );

  const value = useMemo(
    () => ({
      language,
      setLanguage,
      available: LANGUAGES,
      ready,
      speechRate: settings.speechRate,
      setSpeechRate,
      autoSpeak: settings.autoSpeak,
      setAutoSpeak,
      showReadingOnFront: settings.showReadingOnFront,
      setShowReadingOnFront,
      themeMood: settings.themeMood,
      setThemeMood,
    }),
    [
      language,
      setLanguage,
      ready,
      settings,
      setSpeechRate,
      setAutoSpeak,
      setShowReadingOnFront,
      setThemeMood,
    ],
  );

  return <LearnContext.Provider value={value}>{children}</LearnContext.Provider>;
}

export function useLearn(): LearnContextValue {
  const ctx = useContext(LearnContext);
  if (!ctx) {
    throw new Error("useLearn must be used inside <LearnProvider>");
  }
  return ctx;
}
