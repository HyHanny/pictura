"use client";

const KEY = "pictura.session";

export function getSessionId(): string {
  if (typeof window === "undefined") return "ssr";
  let id = window.localStorage.getItem(KEY);
  if (!id) {
    id = "sess-" + Math.random().toString(36).slice(2, 10) + "-" + Date.now().toString(36);
    window.localStorage.setItem(KEY, id);
  }
  return id;
}
