import { sql } from "drizzle-orm";
import { db } from "@/db";
import { cards } from "@/db/schema";
import { CATEGORY_INFO, type CardCategory } from "./categories";
import { VOCABULARY_PART_1 } from "./vocabularyPart1";
import { VOCABULARY_PART_2 } from "./vocabularyPart2";

export { CATEGORY_INFO, type CardCategory };

export type ThaiCn = {
  thai?: string;
  thaiReading?: string;
  thaiExample?: string;
  thaiExampleReading?: string;
  chinese?: string;
  chineseReading?: string;
  chineseExample?: string;
  chineseExampleReading?: string;
};

export type CardData = {
  indonesian: string;
  english: string;
  pronunciation: string;
  category: CardCategory;
  emoji: string;
  gradient: string;
  exampleId?: string;
  exampleEn?: string;
} & ThaiCn;

export const VOCABULARY: CardData[] = [
  ...VOCABULARY_PART_1,
  ...VOCABULARY_PART_2,
];

let tablesEnsured = false;

export async function ensureTablesExist(): Promise<void> {
  if (tablesEnsured) return;
  await db.execute(sql`
    DO $$ BEGIN
      CREATE TYPE "public"."category" AS ENUM(
        'hewan', 'buah', 'warna', 'angka', 'makanan', 'benda', 'tubuh', 'alam',
        'keluarga', 'aktivitas', 'tempat', 'transportasi', 'pakaian', 'emosi', 'waktu', 'profesi'
      );
    EXCEPTION
      WHEN duplicate_object THEN null;
    END $$;
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS "cards" (
      "id" serial PRIMARY KEY NOT NULL,
      "indonesian" text NOT NULL,
      "english" text NOT NULL,
      "pronunciation" text NOT NULL,
      "category" "category" NOT NULL,
      "emoji" text NOT NULL,
      "gradient" text NOT NULL,
      "example_id" text,
      "example_en" text,
      "thai" text,
      "thai_reading" text,
      "thai_example" text,
      "thai_example_reading" text,
      "chinese" text,
      "chinese_reading" text,
      "chinese_example" text,
      "chinese_example_reading" text,
      "created_at" timestamp DEFAULT now() NOT NULL
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS "favorites" (
      "id" serial PRIMARY KEY NOT NULL,
      "card_id" integer NOT NULL REFERENCES "cards"("id") ON DELETE cascade,
      "session_id" text NOT NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS "progress" (
      "id" serial PRIMARY KEY NOT NULL,
      "session_id" text NOT NULL,
      "card_id" integer NOT NULL REFERENCES "cards"("id") ON DELETE cascade,
      "remembered" boolean NOT NULL,
      "reviewed_at" timestamp DEFAULT now() NOT NULL
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS "xp" (
      "id" serial PRIMARY KEY NOT NULL,
      "session_id" text NOT NULL,
      "total_xp" integer DEFAULT 0 NOT NULL,
      "level" integer DEFAULT 1 NOT NULL,
      "last_seen_date" date,
      "streak" integer DEFAULT 0 NOT NULL,
      "longest_streak" integer DEFAULT 0 NOT NULL,
      "updated_at" timestamp DEFAULT now() NOT NULL
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS "unlocked_badges" (
      "id" serial PRIMARY KEY NOT NULL,
      "session_id" text NOT NULL,
      "code" text NOT NULL,
      "unlocked_at" timestamp DEFAULT now() NOT NULL
    );
  `);

  await db.execute(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS "uq_session_badge" ON "unlocked_badges" ("session_id", "code");
  `);

  tablesEnsured = true;
}

export async function seedDatabaseIfEmpty(): Promise<void> {
  await ensureTablesExist();

  const existing = await db
    .select({ indonesian: cards.indonesian, english: cards.english })
    .from(cards);

  if (existing.length >= VOCABULARY.length) {
    return;
  }

  const existingKeys = new Set(
    existing.map((e) => `${e.indonesian.toLowerCase()}::${e.english.toLowerCase()}`),
  );

  const missing = VOCABULARY.filter(
    (v) => !existingKeys.has(`${v.indonesian.toLowerCase()}::${v.english.toLowerCase()}`),
  );

  if (missing.length > 0) {
    await db.insert(cards).values(
      missing.map((v) => ({
        indonesian: v.indonesian,
        english: v.english,
        pronunciation: v.pronunciation,
        category: v.category,
        emoji: v.emoji,
        gradient: v.gradient,
        exampleId: v.exampleId ?? null,
        exampleEn: v.exampleEn ?? null,
        thai: v.thai ?? null,
        thaiReading: v.thaiReading ?? null,
        thaiExample: v.thaiExample ?? null,
        thaiExampleReading: v.thaiExampleReading ?? null,
        chinese: v.chinese ?? null,
        chineseReading: v.chineseReading ?? null,
        chineseExample: v.chineseExample ?? null,
        chineseExampleReading: v.chineseExampleReading ?? null,
      })),
    );
  }
}
