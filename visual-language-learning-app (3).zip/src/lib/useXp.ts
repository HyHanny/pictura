"use client";

import { useCallback, useEffect, useState } from "react";
import { BADGES, BADGE_BY_CODE, type BadgeDef, type LevelInfo, levelFromXp } from "./gamification";
import { getSessionId } from "./session";

export type XpState = {
  totalXp: number;
  level: number;
  streak: number;
  longestStreak: number;
  lastSeenDate: string | null;
};

const INITIAL_XP: XpState = {
  totalXp: 0,
  level: 1,
  streak: 0,
  longestStreak: 0,
  lastSeenDate: null,
};

type UnlockedBadgeWithDef = BadgeDef & { unlockedAt: number };

export function useXp() {
  const [xp, setXp] = useState<XpState>(INITIAL_XP);
  const [badges, setBadges] = useState<UnlockedBadgeWithDef[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [levelInfo, setLevelInfo] = useState<LevelInfo>(levelFromXp(0));

  const refresh = useCallback(async () => {
    try {
      const sid = getSessionId();
      const [xpRes, badgeRes] = await Promise.all([
        fetch(`/api/xp?sessionId=${sid}`),
        fetch(`/api/badges?sessionId=${sid}`),
      ]);
      const xpData = await xpRes.json();
      const badgeData = await badgeRes.json();
      if (xpData.ok) {
        const next: XpState = {
          totalXp: xpData.xp.totalXp,
          level: xpData.xp.level,
          streak: xpData.xp.streak,
          longestStreak: xpData.xp.longestStreak,
          lastSeenDate: xpData.xp.lastSeenDate,
        };
        setXp(next);
        setLevelInfo(levelFromXp(next.totalXp));
      }
      if (badgeData.ok) {
        // Server returns just code unlock info; reconstruct with metadata.
        const codes = new Set(badgeData.unlocked as string[]);
        setBadges(
          BADGES.filter((b) => codes.has(b.code)).map((b) => ({ ...b, unlockedAt: Date.now() })),
        );
      }
      setLoaded(true);
    } catch {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const award = useCallback(
    async (
      payload: {
        source?: "flashcard" | "quiz" | "streak" | "manual";
        correct?: boolean;
        delta?: number;
        perfectQuizSize?: number;
        quizCorrectCount?: number;
      } = {},
    ) => {
      try {
        const sid = getSessionId();
        const res = await fetch(`/api/xp?sessionId=${sid}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.ok) {
          const next: XpState = {
            totalXp: data.xp.totalXp,
            level: data.xp.level,
            streak: data.xp.streak,
            longestStreak: data.xp.longestStreak,
            lastSeenDate: data.xp.lastSeenDate,
          };
          const leveledUp = next.level > xp.level;
          setXp(next);
          setLevelInfo(levelFromXp(next.totalXp));

          // Refresh badge list (server may have unlocked new ones)
          const newBadges = (data.newBadges as string[]) ?? [];
          if (newBadges.length > 0) {
            await refresh();
          } else {
            // Sync badges anyway
            const badgesRes = await fetch(`/api/badges?sessionId=${sid}`);
            const badgesData = await badgesRes.json();
            if (badgesData.ok) {
              const codes = new Set(badgesData.unlocked as string[]);
              setBadges(
                BADGES.filter((b) => codes.has(b.code)).map((b) => ({ ...b, unlockedAt: Date.now() })),
              );
            }
          }
          return { ...next, newBadges, leveledUp };
        }
      } catch {
        /* ignore */
      }
      return null;
    },
    [xp.level, refresh],
  );

  const checkCategoryMaster = useCallback(async () => {
    try {
      const sid = getSessionId();
      const res = await fetch(`/api/badges?sessionId=${sid}`, { method: "POST" });
      const data = await res.json();
      if (data.ok && (data.newlyUnlocked as string[] | undefined)?.length) {
        await refresh();
        return data.newlyUnlocked as string[];
      }
    } catch {
      /* ignore */
    }
    return [] as string[];
  }, [refresh]);

  return { xp, levelInfo, badges, loaded, award, refresh, checkCategoryMaster, BADGE_BY_CODE };
}
