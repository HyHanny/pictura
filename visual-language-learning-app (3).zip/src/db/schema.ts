import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  pgEnum,
  date,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const categoryEnum = pgEnum("category", [
  "hewan",
  "buah",
  "warna",
  "angka",
  "makanan",
  "benda",
  "tubuh",
  "alam",
  "keluarga",
  "aktivitas",
  "tempat",
  "transportasi",
  "pakaian",
  "emosi",
  "waktu",
  "profesi",
]);

export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  indonesian: text("indonesian").notNull(),
  english: text("english").notNull(),
  pronunciation: text("pronunciation").notNull(),
  category: categoryEnum("category").notNull(),
  emoji: text("emoji").notNull(),
  gradient: text("gradient").notNull(),
  exampleId: text("example_id"),
  exampleEn: text("example_en"),
  // Thai
  thai: text("thai"),
  thaiReading: text("thai_reading"), // romanization
  thaiExample: text("thai_example"),
  thaiExampleReading: text("thai_example_reading"),
  // Chinese (Simplified + Pinyin)
  chinese: text("chinese"),
  chineseReading: text("chinese_reading"), // pinyin with tone marks
  chineseExample: text("chinese_example"),
  chineseExampleReading: text("chinese_example_reading"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  cardId: integer("card_id").references(() => cards.id, { onDelete: "cascade" }).notNull(),
  sessionId: text("session_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const progress = pgTable("progress", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  cardId: integer("card_id").references(() => cards.id, { onDelete: "cascade" }).notNull(),
  remembered: boolean("remembered").notNull(),
  reviewedAt: timestamp("reviewed_at").defaultNow().notNull(),
});

export const xp = pgTable("xp", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  totalXp: integer("total_xp").notNull().default(0),
  level: integer("level").notNull().default(1),
  lastSeenDate: date("last_seen_date"),
  streak: integer("streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const unlockedBadges = pgTable(
  "unlocked_badges",
  {
    id: serial("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    code: text("code").notNull(),
    unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
  },
  (t) => ({
    uniq: uniqueIndex("uq_session_badge").on(t.sessionId, t.code),
  }),
);
